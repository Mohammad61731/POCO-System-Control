# Roadmap
- [x] v0.1.0 — scaffold
- [x] v0.2.0 — package inventory
- [x] v0.3.0 — built-in ADB (pairing, connect), guarded package actions, history + undo
- [x] v0.4.0 — notification pairing, stable signing, diagnosis, multi-select, restore-all/reapply, report export
- [ ] v0.5.0 — diagnostics / heat-related info
