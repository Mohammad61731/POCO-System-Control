# Security rules
1. No root; no hidden actions. Every operation shows its exact command and needs confirmation.
2. Only typed operations (enum Op); package names must match a strict regex AND exist in the scanned inventory.
3. Protected packages (SystemUI, phone, settings, thermal, power, security, package installer, permission controller, GMS, launcher, vendor) are blocked for every operation.
4. Unknown system packages default to Caution.
5. Result is verified after state-changing operations and recorded in history.
6. Undo re-checks the current package state first.
7. Uninstall-for-user is distinct from disable and update removal.
8. Gaming mode must not alter thermal limits or CPU/GPU frequencies.
9. ADB key is stored in app-private storage; backup is disabled.
