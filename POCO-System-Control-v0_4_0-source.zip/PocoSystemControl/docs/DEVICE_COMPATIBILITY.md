# Device compatibility
Target: POCO X6 Pro, HyperOS global. minSdk 30 (Wireless debugging). Verify behavior on the device before relying on it.
