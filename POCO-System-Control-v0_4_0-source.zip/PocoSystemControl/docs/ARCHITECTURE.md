# Architecture
Single module, Kotlin + Compose (RTL). Files: Model.kt (apps, ops, safety policy), Adb.kt (libadb-android client + executor with verification),
MainViewModel.kt (state, pairing discovery, history), MainActivity.kt (3 tabs: connect / apps / history).
