package com.poco.systemcontrol

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.io.File

// ---------------------------------------------------------------------------------------------
// HyperOS appearance tools (assets/appearance_tools.json).
// Each tool is a list of `setprop` commands. Nothing is free-text: property names and values are
// validated, the previous values are saved before any change, and the result is checked with getprop.
// ---------------------------------------------------------------------------------------------

data class PropCmd(val prop: String, val value: String, val off: String = "")

data class AppearanceTool(
    val id: String,
    val nameFa: String,
    val nameEn: String,
    val descriptionFa: String,
    val commands: List<PropCmd>,
    val needs: String,            // none | restart
    val warningFa: String,
    val powerWarning: Boolean,
    val os: OsSupport
) {
    val runnable: Boolean get() = commands.isNotEmpty()
    val needsText: String?
        get() = if (needs == "restart") "ممکن است برای اعمال کامل، ری‌استارت SystemUI یا ریبوت لازم باشد." else null
}

data class ToolLink(val title: String, val url: String)

class ToolDb(val version: String, val tools: List<AppearanceTool>, val links: List<ToolLink>) {
    companion object {
        const val ASSET = "appearance_tools.json"
        const val FILE = "appearance_tools.json"
        val EMPTY = ToolDb("-", emptyList(), emptyList())

        // Only these property namespaces may ever be written; ro.* and everything else is refused.
        private const val ALLOWED_PREFIX = "persist.sys."
        private val propRegex = Regex("^[A-Za-z0-9._]{1,80}$")
        private val valueRegex = Regex("^[A-Za-z0-9._-]{0,40}$")

        fun isValid(c: PropCmd) = c.prop.startsWith(ALLOWED_PREFIX) && propRegex.matches(c.prop) &&
            valueRegex.matches(c.value) && c.value.isNotEmpty() && valueRegex.matches(c.off)

        fun parse(text: String): ToolDb {
            val root = JSONObject(text)
            require(root.optString("kind") == "tools") { "kind" }
            val arr = root.getJSONArray("tools")
            val tools = ArrayList<AppearanceTool>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id")
                if (!Regex("^[a-z0-9_]{1,40}$").matches(id)) continue
                val cmds = ArrayList<PropCmd>()
                val ca = o.optJSONArray("commands")
                var bad = false
                if (ca != null) for (j in 0 until ca.length()) {
                    val c = ca.optJSONObject(j) ?: continue
                    val cmd = PropCmd(c.optString("prop"), c.optString("value"), c.optString("off"))
                    if (isValid(cmd)) cmds += cmd else bad = true
                }
                if (bad) continue // a tool with any invalid command is dropped as a whole
                val osObj = o.optJSONObject("osSupport")
                tools += AppearanceTool(
                    id = id,
                    nameFa = o.optString("nameFa").ifBlank { id },
                    nameEn = o.optString("nameEn"),
                    descriptionFa = o.optString("descriptionFa"),
                    commands = cmds,
                    needs = o.optString("needs", "none"),
                    warningFa = o.optString("warningFa"),
                    powerWarning = o.optBoolean("powerWarning", false),
                    os = OsSupport(
                        osObj?.takeIf { it.has("androidMin") }?.optInt("androidMin"),
                        osObj?.takeIf { it.has("androidMax") }?.optInt("androidMax"),
                        osObj?.optJSONArray("hyperosVersions").doubles()
                    )
                )
            }
            require(tools.isNotEmpty()) { "empty" }
            val links = ArrayList<ToolLink>()
            root.optJSONArray("links")?.let { la ->
                for (i in 0 until la.length()) {
                    val l = la.optJSONObject(i) ?: continue
                    val url = l.optString("url")
                    if (url.startsWith("https://")) links += ToolLink(l.optString("title", url), url)
                }
            }
            return ToolDb(root.optString("dbVersion", "0"), tools, links)
        }

        fun load(ctx: Context): ToolDb {
            val asset = JsonStore.asset(ctx, ASSET)
            val over = JsonStore.override(ctx, FILE)
            if (over != null && JsonStore.versionOf(over) >= JsonStore.versionOf(asset)) {
                runCatching { return parse(over) }
            }
            return parse(asset)
        }
    }
}

fun AppearanceTool.osWarning(d: DeviceInfo): String? = os.warningText(d)

private fun OsSupport.warningText(d: DeviceInfo): String? {
    val h = d.hyperos
    if (h != null && hyperos.isNotEmpty() && hyperos.none { kotlin.math.abs(it - h) < 0.05 }) {
        return "برای HyperOS $h تأیید نشده؛ بعد از اجرا نتیجه بررسی می‌شود."
    }
    return null
}

/** Remembers the values that were in place before a tool changed them, so they can be restored. */
class ToolStore(ctx: Context) {
    private val file = File(ctx.filesDir, "tool_prior.json")

    private fun read(): JSONObject = runCatching { JSONObject(file.readText()) }.getOrDefault(JSONObject())

    fun get(id: String): Map<String, String>? {
        val o = read().optJSONObject(id) ?: return null
        return o.keys().asSequence().associateWith { o.optString(it) }
    }

    fun save(id: String, values: Map<String, String>) {
        val root = read()
        root.put(id, JSONObject(values))
        runCatching { file.writeText(root.toString()) }
    }

    fun clear(id: String) {
        val root = read()
        root.remove(id)
        runCatching { file.writeText(root.toString()) }
    }
}

object AppearanceRunner {
    /**
     * The shell user cannot write persist.sys.* directly. Xiaomi's system service miui.mqsas.IMQSNative
     * (transaction 21) runs `setprop` with system privileges; this is the method used by the video and
     * by Brevent's "Exsec Command". Name and value are validated before they reach this string.
     */
    fun shellCommand(prop: String, value: String): String =
        "service call miui.mqsas.IMQSNative 21 i32 1 s16 \"setprop\" i32 1 s16 \"$prop $value\" " +
            "s16 \"/storage/emulated/0/log.txt\" i32 600"

    private suspend fun readProps(adb: AppAdbManager, props: List<String>): Map<String, String> =
        props.associateWith { adb.exec("getprop $it", 8_000L).trim() }

    /** true = every property already has the tool's target value. */
    suspend fun isApplied(adb: AppAdbManager, tool: AppearanceTool): Boolean {
        if (!tool.runnable) return false
        val cur = readProps(adb, tool.commands.map { it.prop })
        return tool.commands.all { cur[it.prop] == it.value }
    }

    private suspend fun set(adb: AppAdbManager, prop: String, value: String) {
        adb.exec(shellCommand(prop, value), 10_000L)
    }

    /** The system applies the change asynchronously, so poll getprop for a few seconds. */
    private suspend fun waitFor(adb: AppAdbManager, target: Map<String, String>): Map<String, String> {
        var cur = readProps(adb, target.keys.toList())
        repeat(5) {
            if (target.all { (p, v) -> cur[p] == v }) return cur
            delay(1_000L)
            cur = readProps(adb, target.keys.toList())
        }
        return cur
    }

    suspend fun apply(adb: AppAdbManager, tool: AppearanceTool, store: ToolStore): OpResult = try {
        applyInner(adb, tool, store)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Throwable) {
        OpResult(false, "خطا یا قطع اتصال ADB: ${e.localizedMessage ?: e.javaClass.simpleName}. اتصال را در تب «اتصال» دوباره بررسی کن.")
    }

    suspend fun revert(adb: AppAdbManager, tool: AppearanceTool, store: ToolStore): OpResult = try {
        revertInner(adb, tool, store)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Throwable) {
        OpResult(false, "خطا یا قطع اتصال ADB: ${e.localizedMessage ?: e.javaClass.simpleName}")
    }

    private suspend fun applyInner(adb: AppAdbManager, tool: AppearanceTool, store: ToolStore): OpResult {
        if (!tool.runnable || !tool.commands.all(ToolDb::isValid)) return OpResult(false, "دستور معتبری برای این ابزار نیست")
        val before = readProps(adb, tool.commands.map { it.prop })
        val alreadyApplied = tool.commands.all { before[it.prop] == it.value }
        if (!alreadyApplied && store.get(tool.id) == null) store.save(tool.id, before)

        // One command at a time, in order.
        for (c in tool.commands) {
            set(adb, c.prop, c.value)
            delay(400L)
        }
        val target = tool.commands.associate { it.prop to it.value }
        val after = waitFor(adb, target)
        if (target.all { (p, v) -> after[p] == v }) return OpResult(true, tool.nameFa)

        // Not applied: put back what was there (or the tool's "off" value if the property was unset).
        runCatching {
            for (c in tool.commands) {
                if (after[c.prop] != before[c.prop]) set(adb, c.prop, before[c.prop].orEmpty().ifBlank { c.off }.ifBlank { null } ?: continue)
            }
        }
        if (!alreadyApplied) store.clear(tool.id)
        val got = tool.commands.joinToString("، ") { "${it.prop}=${after[it.prop].orEmpty().ifBlank { "(خالی)" }}" }
        return OpResult(false, "اعمال نشد؛ مقدار بعد از اجرا: $got")
    }

    private suspend fun revertInner(adb: AppAdbManager, tool: AppearanceTool, store: ToolStore): OpResult {
        if (!tool.runnable || !tool.commands.all(ToolDb::isValid)) return OpResult(false, "دستور معتبری برای این ابزار نیست")
        val prior = store.get(tool.id)
        // Saved previous value if there is one; otherwise the tool's "off" value.
        val target = tool.commands.associate { c -> c.prop to (prior?.get(c.prop)?.takeIf { it.isNotBlank() } ?: c.off) }
        if (target.values.any { it.isBlank() }) return OpResult(false, "مقدار بازگشت برای این ابزار مشخص نیست")
        for ((p, v) in target) {
            set(adb, p, v)
            delay(400L)
        }
        val after = waitFor(adb, target)
        val ok = target.all { (p, v) -> after[p] == v }
        if (ok) store.clear(tool.id)
        return OpResult(ok, if (ok) tool.nameFa else "بازگردانی تأیید نشد؛ مقدار فعلی را بررسی کن")
    }
}
