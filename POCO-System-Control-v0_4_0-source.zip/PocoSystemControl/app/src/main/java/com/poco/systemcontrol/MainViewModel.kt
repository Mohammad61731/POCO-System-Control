package com.poco.systemcontrol

import android.app.Application
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Conn { DISCONNECTED, CONNECTED }

data class HistoryEntry(
    val time: Long, val op: Op, val pkg: String, val label: String, val ok: Boolean, val msg: String
)

data class DiagRow(val proc: String, val cpu: Double, val app: AppItem?)
data class DiagResult(val tempC: Double?, val level: Int?, val rows: List<DiagRow>)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val adb = AppAdbManager.get(ctx)
    private val logFile = File(ctx.filesDir, "history.log")

    var apps by mutableStateOf<List<AppItem>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var busy by mutableStateOf(false); private set
    var conn by mutableStateOf(Conn.DISCONNECTED); private set
    var diag by mutableStateOf<DiagResult?>(null); private set
    var message by mutableStateOf<String?>(null)
    var pairingPort by mutableStateOf("")
    val history = mutableStateListOf<HistoryEntry>()

    init {
        loadHistory()
        scan()
        refreshConn(3_000L)
    }

    fun scan() {
        viewModelScope.launch {
            loading = true
            apps = withContext(Dispatchers.IO) {
                runCatching { loadApps(ctx.packageManager, ctx.packageName) }.getOrDefault(emptyList())
            }
            loading = false
        }
    }

    private suspend fun doConnect(timeout: Long): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            if (!adb.isConnected()) adb.connectTls(ctx, timeout)
            adb.isConnected()
        }.getOrDefault(false)
    }

    /** Called at start and on resume (pairing may have happened from the notification). */
    fun refreshConn(timeout: Long = 1_500L) {
        viewModelScope.launch {
            conn = if (doConnect(timeout)) Conn.CONNECTED else Conn.DISCONNECTED
        }
    }

    fun connect() {
        if (busy) return
        viewModelScope.launch {
            busy = true
            val ok = doConnect(10_000L)
            conn = if (ok) Conn.CONNECTED else Conn.DISCONNECTED
            message = if (ok) "به ADB داخلی وصل شد" else
                "اتصال برقرار نشد. Wireless debugging روشن و گوشی به Wi‑Fi وصل باشد؛ اگر اولین بار است ابتدا جفت‌سازی کن."
            busy = false
        }
    }

    fun pair(code: String) {
        val port = pairingPort.trim().toIntOrNull()
        if (port == null || code.trim().length != 6) {
            message = "پورت جفت‌سازی و کد ۶ رقمی را وارد کن"
            return
        }
        if (busy) return
        viewModelScope.launch {
            busy = true
            val paired = withContext(Dispatchers.IO) {
                runCatching { adb.pair("127.0.0.1", port, code.trim()) }.getOrDefault(false)
            }
            if (paired) {
                val ok = doConnect(10_000L)
                conn = if (ok) Conn.CONNECTED else Conn.DISCONNECTED
                message = if (ok) "جفت‌سازی و اتصال موفق بود" else "جفت‌سازی شد؛ روی «اتصال» بزن"
            } else {
                message = "جفت‌سازی ناموفق بود. کد و پورت را دوباره از صفحهٔ Wireless debugging بگیر."
            }
            busy = false
        }
    }

    private suspend fun runAndLog(op: Op, app: AppItem, snapshot: List<AppItem>): OpResult {
        val r = withContext(Dispatchers.IO) { Executor.run(adb, op, app.pkg, snapshot) }
        addHistory(HistoryEntry(System.currentTimeMillis(), op, app.pkg, app.label, r.ok, r.text))
        return r
    }

    private suspend fun finishRun() {
        val still = withContext(Dispatchers.IO) { runCatching { adb.isConnected() }.getOrDefault(false) }
        conn = if (still) Conn.CONNECTED else Conn.DISCONNECTED
        busy = false
        scan()
    }

    private fun guard(): Boolean {
        if (busy) return false
        if (conn != Conn.CONNECTED) {
            message = "ابتدا در تب «اتصال» ADB داخلی را وصل کن"
            return false
        }
        return true
    }

    fun execute(op: Op, app: AppItem) {
        if (!guard()) return
        viewModelScope.launch {
            busy = true
            val r = runAndLog(op, app, apps)
            message = (if (r.ok) "انجام شد: " else "ناموفق: ") + r.text
            finishRun()
        }
    }

    fun executeBatch(op: Op, items: List<AppItem>) = runBatch(items.map { op to it })

    private fun runBatch(list: List<Pair<Op, AppItem>>) {
        if (list.isEmpty()) {
            message = "چیزی برای اجرا نیست"
            return
        }
        if (!guard()) return
        viewModelScope.launch {
            busy = true
            val snapshot = apps
            var okCount = 0
            for ((op, a) in list) {
                if (runAndLog(op, a, snapshot).ok) okCount++
            }
            message = "$okCount از ${list.size} عملیات موفق بود"
            finishRun()
        }
    }

    /** Undo re-checks the current package state before doing anything. */
    fun undo(e: HistoryEntry) {
        val u = e.op.undo ?: return
        val item = apps.firstOrNull { it.pkg == e.pkg }
        if (item == null) {
            message = "برنامه در فهرست فعلی پیدا نشد"
            return
        }
        if (!stateAllows(u, item)) {
            message = "وضعیت فعلی برنامه با این بازگردانی نمی‌خواند"
            return
        }
        execute(u, item)
    }

    private fun stateAllows(op: Op, a: AppItem): Boolean = when (op) {
        Op.ENABLE -> !a.isEnabled && a.isInstalled
        Op.RESTORE -> !a.isInstalled
        Op.DISABLE -> a.isEnabled && a.isInstalled
        Op.UNINSTALL_USER -> a.isInstalled
        else -> a.isInstalled
    }

    /** Latest applying operation per package/group that has not been reversed afterwards. */
    private fun profile(): List<Pair<Op, String>> {
        val last = LinkedHashMap<String, Pair<Op, String>>()
        history.reversed().filter { it.ok }.forEach { e ->
            if (e.op in applyingOps || e.op.undo != null) last[e.pkg + "|" + e.op.group] = e.op to e.pkg
        }
        return last.values.filter { it.first in applyingOps }
    }

    fun profileSize(): Int = profile().size

    fun restoreAll() {
        val list = profile().mapNotNull { (op, pkg) ->
            val a = apps.firstOrNull { it.pkg == pkg } ?: return@mapNotNull null
            val u = op.undo ?: return@mapNotNull null
            if (stateAllows(u, a)) u to a else null
        }
        runBatch(list)
    }

    fun reapplyAll() {
        val list = profile().mapNotNull { (op, pkg) ->
            val a = apps.firstOrNull { it.pkg == pkg } ?: return@mapNotNull null
            if (op == Op.DISABLE && !(a.isInstalled && a.isEnabled)) return@mapNotNull null
            if (op == Op.UNINSTALL_USER && !a.isInstalled) return@mapNotNull null
            if (a.risk == Risk.PROTECTED) null else op to a
        }
        runBatch(list)
    }

    fun report(): String {
        val fmt = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US)
        val sb = StringBuilder()
        sb.append("POCO System Control 0.4.0\n")
        sb.append("${Build.MANUFACTURER} ${Build.MODEL} • Android ${Build.VERSION.RELEASE}\n\n")
        sb.append("وضعیت فعلی اعمال‌شده:\n")
        profile().forEach { (op, pkg) -> sb.append("• ${op.title}: $pkg\n") }
        sb.append("\nسابقه:\n")
        history.reversed().forEach {
            sb.append("${fmt.format(Date(it.time))} | ${it.op.name} | ${it.pkg} | ${if (it.ok) "OK" else "FAIL"}\n")
        }
        return sb.toString()
    }

    // ---- diagnosis: who is heating the phone ----
    fun diagnose() {
        if (!guard()) return
        viewModelScope.launch {
            busy = true
            val snapshot = apps
            val res = withContext(Dispatchers.IO) {
                runCatching {
                    val bat = adb.exec("dumpsys battery")
                    val temp = Regex("temperature:\\s*(\\d+)").find(bat)?.groupValues?.get(1)?.toDoubleOrNull()?.div(10)
                    val level = Regex("level:\\s*(\\d+)").find(bat)?.groupValues?.get(1)?.toIntOrNull()
                    val rx = Regex("^\\s*([0-9.]+)%\\s+\\d+/([^:\\s]+)")
                    val rows = adb.exec("dumpsys cpuinfo").lineSequence()
                        .mapNotNull { l -> rx.find(l)?.let { m -> m.groupValues[2] to (m.groupValues[1].toDoubleOrNull() ?: 0.0) } }
                        .groupBy({ it.first }, { it.second })
                        .map { (k, v) -> k to v.sum() }
                        .sortedByDescending { it.second }
                        .take(15)
                        .map { (proc, c) -> DiagRow(proc, c, snapshot.firstOrNull { it.pkg == proc }) }
                    DiagResult(temp, level, rows)
                }.getOrNull()
            }
            diag = res
            if (res == null) message = "تشخیص ناموفق بود"
            busy = false
        }
    }

    // ---- pairing port discovery (mDNS) ----
    private var nsdListener: NsdManager.DiscoveryListener? = null

    fun startPairingDiscovery() {
        if (nsdListener != null) return
        val nsd = ctx.getSystemService(NsdManager::class.java) ?: return
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { nsdListener = null }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onServiceLost(serviceInfo: NsdServiceInfo) {}
            @Suppress("DEPRECATION")
            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                runCatching {
                    nsd.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
                        override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                            pairingPort = serviceInfo.port.toString()
                            PairingHelper.port = serviceInfo.port
                        }
                    })
                }
            }
        }
        nsdListener = l
        runCatching { nsd.discoverServices("_adb-tls-pairing._tcp", NsdManager.PROTOCOL_DNS_SD, l) }
    }

    fun stopPairingDiscovery() {
        val l = nsdListener ?: return
        nsdListener = null
        runCatching { ctx.getSystemService(NsdManager::class.java)?.stopServiceDiscovery(l) }
    }

    // ---- history ----
    private fun clean(s: String) = s.replace('\t', ' ').replace('\n', ' ')

    private fun addHistory(e: HistoryEntry) {
        history.add(0, e)
        runCatching {
            logFile.appendText("${e.time}\t${e.op.name}\t${e.pkg}\t${clean(e.label)}\t${e.ok}\t${clean(e.msg)}\n")
        }
    }

    private fun loadHistory() {
        runCatching {
            if (!logFile.exists()) return
            logFile.readLines().takeLast(300).mapNotNull { line ->
                val p = line.split("\t", limit = 6)
                if (p.size < 6) return@mapNotNull null
                val op = runCatching { Op.valueOf(p[1]) }.getOrNull() ?: return@mapNotNull null
                HistoryEntry(p[0].toLongOrNull() ?: 0L, op, p[2], p[3], p[4] == "true", p[5])
            }.reversed().forEach { history.add(it) }
        }
    }
}
