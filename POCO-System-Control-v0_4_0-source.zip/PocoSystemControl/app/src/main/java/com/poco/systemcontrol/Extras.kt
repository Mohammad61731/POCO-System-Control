package com.poco.systemcontrol

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

// ---------------------------------------------------------------------------------------------
// 1) Keyboard bottom gap (black bar under the keyboard): manual method + ADB method.
// 2) AI features checklist: checks what the app can read; the rest is a manual checklist.
// ---------------------------------------------------------------------------------------------

/** Gesture-line overlay that makes the IME reserve a navigation-bar row (IRDcode/hyperos-keyboard-gap-fix, XimiTime). */
private const val GAP_OVERLAY = "com.android.systemui.gesture.line.overlay"

@Composable
fun KeyboardFixCard(vm: MainViewModel) {
    val overlay = vm.apps.firstOrNull { it.pkg == GAP_OVERLAY }
    var confirm by remember { mutableStateOf<Op?>(null) }
    val canRun = vm.conn == Conn.CONNECTED && !vm.busy

    confirm?.let { op ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(if (op == Op.UNINSTALL_USER) "رفع نوار مشکی کیبورد (ADB)" else "بازگرداندن overlay") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(commandFor(op, GAP_OVERLAY), fontSize = 11.sp)
                    if (op == Op.RESTORE) Text("cmd overlay enable-exclusive --user 0 $GAP_OVERLAY", fontSize = 11.sp)
                    Text(
                        if (op == Op.UNINSTALL_USER) "فقط برای کاربر 0 غیرفعال می‌شود؛ APK در /product/overlay دست‌نخورده می‌ماند. بعد از اجرا HyperOS به ناوبری ۳دکمه‌ای برمی‌گردد: تنظیمات ← صفحه اصلی ← ناوبری سیستم ← «ژست‌ها» را دوباره انتخاب کن و «Hide full screen indicator» را روشن کن. ریبوت لازم نیست؛ اگر کیبورد هنوز فاصله دارد آن را یک‌بار Force stop کن. نتیجه در «سابقه» ثبت می‌شود."
                        else "overlay دوباره نصب و فعال می‌شود (فقط install-existing آن را غیرفعال برمی‌گرداند).",
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    overlay?.let { if (op == Op.RESTORE) vm.gapRevert(it) else vm.execute(op, it) }
                    confirm = null
                }) { Text("تأیید و اجرا") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("انصراف") } }
        )
    }

    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("رفع نوار مشکی زیر کیبورد", style = MaterialTheme.typography.titleMedium)
            Text("فقط اگر زیر کیبورد نوار مشکی/ردیف فلش پایین دیده می‌شود (بعد از آپدیت HyperOS 3).", fontSize = 12.sp)

            Text("بدون هک (دستی)", style = MaterialTheme.typography.titleSmall)
            Text(
                "روشن‌کردن «Hide full screen indicator» فقط خط ژست را پنهان می‌کند و طبق ریپوی مرجع معمولاً فاصله را برطرف نمی‌کند، ولی بی‌خطر است و اول امتحانش کن: تنظیمات ← صفحه اصلی ← ناوبری سیستم ← ژست‌ها.\n" +
                    "عوض‌کردن کیبورد، پاک‌کردن داده و تم هم طبق همان ریپو اثری ندارد؛ پس راه بدون ADB عملاً همین است و اگر جواب نداد روش پایین.",
                fontSize = 12.sp
            )

            Text("با ADB (برگشت‌پذیر، بدون روت)", style = MaterialTheme.typography.titleSmall)
            Text("علت (طبق ریپوی IRDcode/hyperos-keyboard-gap-fix): overlay زیر مقدار config_imeDrawsImeNavBar را true می‌کند و کیبورد برای خودش ردیف ناوبری رزرو می‌کند. گزارش‌شده روی Xiaomi 13T با HyperOS 3؛ روی POCO X6 Pro تست‌شده نیست.", fontSize = 12.sp)
            Text(GAP_OVERLAY, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            when {
                overlay == null -> Text(
                    "این overlay در فهرست بسته‌های گوشی‌ات نیست؛ یعنی این ROM مشمول این رفع نیست. فقط روش دستی را استفاده کن.",
                    fontSize = 12.sp, color = Color(0xFFFFB74D)
                )
                overlay.risk == Risk.PROTECTED -> Text("این بسته محافظت‌شده است و اپ آن را تغییر نمی‌دهد.", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                else -> {
                    Text(if (overlay.isInstalled) "وضعیت: overlay فعال/نصب است" else "وضعیت: overlay برای کاربر 0 حذف شده", fontSize = 12.sp)
                    if (vm.conn != Conn.CONNECTED) Text("برای اجرا ADB داخلی را در تب «اتصال» وصل کن.", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                    vm.gapCheckText?.let { Text("نتیجهٔ بررسی:\n$it", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { vm.gapCheck() }, enabled = canRun) { Text("بررسی (فقط خواندن)", fontSize = 12.sp) }
                        if (overlay.isInstalled) {
                            Button(onClick = { confirm = Op.UNINSTALL_USER }, enabled = canRun) { Text("اعمال رفع", fontSize = 12.sp) }
                        } else {
                            OutlinedButton(onClick = { confirm = Op.RESTORE }, enabled = canRun) { Text("بازگرداندن", fontSize = 12.sp) }
                        }
                    }
                    Text("هشدار: ریست فکتوری یا OTA کامل ممکن است overlay را برگرداند؛ دوباره اعمال کن.", fontSize = 11.sp)
                }
            }
        }
    }
}

private data class AiApp(val pkg: String, val name: String)

// Names of AI-related Xiaomi packages; each is only reported if it exists on this phone.
private val aiApps = listOf(
    AiApp("com.xiaomi.aiasst.vision", "AI Vision / مترجم تصویری"),
    AiApp("com.xiaomi.aiasst.service", "AI Assistant Service"),
    AiApp("com.miui.voiceassist", "دستیار صوتی (Voice Assist)")
)

private val manualAi = listOf(
    "ai_account" to "با حساب Mi وارد شده‌ام (تنظیمات ← حساب Xiaomi)",
    "ai_region" to "منطقهٔ گوشی مطابق ویژگی‌ها تنظیم است (تنظیمات ← تنظیمات اضافی ← منطقه)",
    "ai_lang" to "زبان سیستم یکی از زبان‌های پشتیبانی‌شدهٔ همان ویژگی است (تنظیمات ← تنظیمات اضافی ← زبان‌ها)",
    "ai_apps" to "اپ‌های مرتبط (Notes، Recorder، Translate و ...) به آخرین نسخه آپدیت شده‌اند",
    "ai_perm" to "در تنظیمات هر قابلیت AI، موافقت‌نامه/مجوزها را پذیرفته‌ام و مدل‌ها دانلود شده‌اند"
)

@Composable
fun AiChecklistCard(vm: MainViewModel) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("ai_checklist", Context.MODE_PRIVATE) }
    val checked = remember { mutableStateMapOf<String, Boolean>().apply { manualAi.forEach { put(it.first, prefs.getBoolean(it.first, false)) } } }
    val region = remember { DeviceInfo.localProp("ro.miui.region").ifBlank { DeviceInfo.localProp("persist.sys.miui_region") } }
    val net = remember {
        runCatching {
            val cm = ctx.getSystemService(ConnectivityManager::class.java)
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            Triple(
                caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true,
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true,
                true
            )
        }.getOrDefault(Triple(false, false, false))
    }

    @Composable
    fun Line(ok: Boolean?, text: String) {
        val c = when (ok) { true -> Color(0xFF66BB6A); false -> Color(0xFFFFB74D); null -> MaterialTheme.colorScheme.onSurfaceVariant }
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(when (ok) { true -> "✔"; false -> "!"; null -> "•" }, color = c, fontSize = 12.sp)
            Text(text, fontSize = 12.sp)
        }
    }

    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("چک‌لیست قابلیت‌های AI", style = MaterialTheme.typography.titleMedium)
            Text("طبق توضیح رسمی شیائومی، قابلیت‌های AI بسته به مدل، زبان، منطقه و اینترنت فعال می‌شوند. راه ADB مطمئنی برای اجبار پیدا نشد؛ این بخش فقط وضعیت را می‌سنجد.", fontSize = 12.sp)

            Text("بررسی خودکار", style = MaterialTheme.typography.titleSmall)
            Line(vm.device.hyperos != null, "نسخه: ${vm.device.androidText} • HyperOS ${vm.device.hyperosText}")
            Line(null, "زبان سیستم: ${Locale.getDefault().getDisplayName(Locale.getDefault())}")
            Line(region.isNotBlank(), "منطقه: ${region.ifBlank { "قابل خواندن نیست (دستی بررسی کن)" }}")
            Line(net.first, if (net.first) "اینترنت فعال است" else "اینترنت فعال نیست؛ قابلیت‌های ابری کار نمی‌کنند")
            Line(!net.second, if (net.second) "VPN روشن است؛ ممکن است منطقه‌ای شدن/دسترسی را تغییر دهد (برای تست خاموشش کن)" else "VPN روشن نیست")

            Text("برنامه‌های مرتبط روی این گوشی", style = MaterialTheme.typography.titleSmall)
            aiApps.forEach { a ->
                val item = vm.apps.firstOrNull { it.pkg == a.pkg }
                when {
                    item == null -> Line(null, "${a.name}: روی این گوشی نصب/دیده نشد")
                    !item.isInstalled -> Line(false, "${a.name}: برای کاربر 0 حذف شده؛ از تب «برنامه‌ها» بازگردانی کن")
                    !item.isEnabled -> Line(false, "${a.name}: غیرفعال است؛ ویژگی‌های وابسته کار نمی‌کنند")
                    else -> Line(true, "${a.name}: فعال • نسخه ${item.versionName}")
                }
            }

            Text("چک‌لیست دستی", style = MaterialTheme.typography.titleSmall)
            manualAi.forEach { (key, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = checked[key] == true, onCheckedChange = {
                        checked[key] = it
                        prefs.edit().putBoolean(key, it).apply()
                    })
                    Text(label, fontSize = 12.sp)
                }
            }
        }
    }
}
