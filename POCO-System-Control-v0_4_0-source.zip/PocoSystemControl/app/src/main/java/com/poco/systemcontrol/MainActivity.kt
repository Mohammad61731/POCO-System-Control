package com.poco.systemcontrol

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AppRoot(vm)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshConn()
    }
}

@Composable
private fun AppRoot(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(if (vm.conn == Conn.CONNECTED) 1 else 0) }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        vm.message?.let {
            snack.showSnackbar(it)
            vm.message = null
        }
    }
    val names = listOf("اتصال", "برنامه‌ها", "ظاهر", "تشخیص", "سابقه")
    val icons = listOf("⌁", "▦", "✦", "🌡", "☰")
    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                names.forEachIndexed { i, n ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(icons[i]) }, label = { Text(n, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { pad ->
        when (tab) {
            0 -> ConnectScreen(vm, pad)
            1 -> AppsScreen(vm, pad)
            2 -> AppearanceScreen(vm, pad)
            3 -> DiagScreen(vm, pad)
            else -> HistoryScreen(vm, pad)
        }
    }
}

@Composable
private fun ConnectScreen(vm: MainViewModel, pad: PaddingValues) {
    val ctx = LocalContext.current
    var code by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { vm.startPairingDiscovery() }
    DisposableEffect(Unit) { onDispose { vm.stopPairingDiscovery() } }

    fun openDevSettings() {
        runCatching { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            PairingHelper.showNotification(ctx, "کد ۶ رقمی را اینجا بنویس", withInput = true)
            openDevSettings()
        } else vm.message = "برای جفت‌سازی با نوتیفیکیشن، اجازهٔ اعلان لازم است"
    }

    Column(
        Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("POCO SYSTEM CONTROL", style = MaterialTheme.typography.labelLarge)
        Text("اتصال ADB داخلی", style = MaterialTheme.typography.headlineSmall)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Text(
                if (vm.conn == Conn.CONNECTED) "● وصل است — می‌توانی در تب «برنامه‌ها» کار کنی" else "○ وصل نیست",
                Modifier.padding(16.dp),
                color = if (vm.conn == Conn.CONNECTED) Color(0xFF66BB6A) else MaterialTheme.colorScheme.error
            )
        }
        Text(
            "فقط یک‌بار لازم است:\n" +
                "۱) گوشی را به یک Wi‑Fi وصل کن (اینترنت لازم نیست).\n" +
                "۲) «اشکال‌زدایی بی‌سیم» را روشن کن.\n" +
                "۳) روش پیشنهادی: دکمهٔ «جفت‌سازی با نوتیفیکیشن» را بزن، در تنظیمات «جفت‌سازی با کد» را باز کن، کد ۶ رقمی را در نوتیفیکیشن بنویس و «ارسال» بزن.\n" +
                "۴) روش دستی: برنامه را در پنجرهٔ شناور/صفحهٔ تقسیم‌شده باز نگه دار، کد را پایین بنویس و «جفت‌سازی» بزن.\n" +
                "۵) بعد روی «اتصال» بزن. بعد از ریستارت فقط Wireless debugging را دوباره روشن کن.",
            style = MaterialTheme.typography.bodyMedium
        )
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= 33 &&
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                PairingHelper.showNotification(ctx, "کد ۶ رقمی را اینجا بنویس", withInput = true)
                openDevSettings()
            }
        }) { Text("جفت‌سازی با نوتیفیکیشن") }
        OutlinedButton(onClick = { openDevSettings() }) { Text("باز کردن گزینه‌های توسعه‌دهنده") }
        OutlinedTextField(
            value = vm.pairingPort, onValueChange = { vm.pairingPort = it.filter(Char::isDigit) },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("پورت جفت‌سازی (خودکار)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        OutlinedTextField(
            value = code, onValueChange = { code = it.filter(Char::isDigit).take(6) },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("کد جفت‌سازی (۶ رقم) — روش دستی") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.pair(code) }, enabled = !vm.busy) { Text("جفت‌سازی") }
            Button(onClick = { vm.connect() }, enabled = !vm.busy) { Text("اتصال") }
        }
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    }
}

@Composable
private fun ConfirmDialog(pending: Pair<Op, AppItem>?, vm: MainViewModel, onClose: () -> Unit) {
    pending?.let { (op, app) ->
        AlertDialog(
            onDismissRequest = onClose,
            title = { Text(op.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(app.label, style = MaterialTheme.typography.titleSmall)
                    Text(app.pkg, style = MaterialTheme.typography.bodySmall)
                    Text("دستوری که اجرا می‌شود:", style = MaterialTheme.typography.labelMedium)
                    Text(commandFor(op, app.pkg), fontSize = 11.sp)
                    if (app.risk == Risk.CAUTION && app.info == null) Text("این بستهٔ سیستمی در دیتابیس نیست؛ مطمئن شو نقشش را می‌دانی.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    if (app.risk == Risk.CAUTION && app.info != null) Text("ریسک: احتیاط — ${app.info.sideEffects}", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    if (op == Op.UNINSTALL_USER && app.isEnabled) Text("پیشنهاد: اول «غیرفعال‌سازی» را بزن و چند روز تست کن؛ بعد حذف.", color = Color(0xFFFFB74D), fontSize = 12.sp)
                    if (op == Op.UNINSTALL_USER) Text("حذف فقط برای کاربر فعلی است و با «بازگردانی» برمی‌گردد.", fontSize = 12.sp)
                    if (op == Op.UNINSTALL_FULL) Text("داده‌های برنامه هم پاک می‌شود و برگشت ندارد.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { vm.execute(op, app); onClose() }) { Text("تأیید و اجرا") } },
            dismissButton = { TextButton(onClick = onClose) { Text("انصراف") } }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AppsScreen(vm: MainViewModel, pad: PaddingValues) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("همه") }
    var detailPkg by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<Pair<Op, AppItem>?>(null) }
    var selecting by remember { mutableStateOf(false) }
    var batchOp by remember { mutableStateOf<Op?>(null) }
    val selected = remember { mutableStateListOf<String>() }
    val filters = listOf("همه", "پیشنهاد حذف", "برای بررسی", "ممنوع", "سیستمی", "کاربر", "غیرفعال", "حذف‌شده")

    val visible = remember(vm.apps, query, filter) {
        vm.apps.filter { a ->
            val q = query.isBlank() || a.label.contains(query, true) || a.pkg.contains(query, true)
            val f = when (filter) {
                "پیشنهاد حذف" -> a.isInstalled && a.risk != Risk.PROTECTED && (a.info?.action == DbAction.REMOVE || a.info?.action == DbAction.DISABLE)
                "برای بررسی" -> a.risk == Risk.CAUTION
                "ممنوع" -> a.risk == Risk.PROTECTED
                "سیستمی" -> a.isSystem
                "کاربر" -> !a.isSystem
                "غیرفعال" -> a.isInstalled && !a.isEnabled
                "حذف‌شده" -> !a.isInstalled
                else -> true
            }
            q && f
        }
    }

    ConfirmDialog(pending, vm) { pending = null }

    detailPkg?.let { p ->
        val app = vm.apps.firstOrNull { it.pkg == p }
        if (app == null) detailPkg = null
        else DetailDialog(app, vm, onPick = { op -> pending = op to app; detailPkg = null }, onClose = { detailPkg = null })
    }

    batchOp?.let { op ->
        val items = vm.apps.filter { it.pkg in selected && op in availableOps(it) }
        AlertDialog(
            onDismissRequest = { batchOp = null },
            title = { Text("${op.title} — ${items.size} برنامه") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (items.isEmpty()) Text("هیچ‌کدام از موارد انتخابی برای این عملیات مناسب نیستند.")
                    items.take(25).forEach { Text("• ${it.label}", fontSize = 13.sp) }
                    if (items.size > 25) Text("و ${items.size - 25} مورد دیگر…", fontSize = 12.sp)
                    if (op == Op.UNINSTALL_USER) Text("پیشنهاد: اول «غیرفعال‌سازی» و چند روز تست؛ بعد حذف.", color = Color(0xFFFFB74D), fontSize = 12.sp)
                    Text("برنامه‌های ممنوع و مواردی که از قبل در این وضعیت‌اند حذف شده‌اند.", fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(enabled = items.isNotEmpty(), onClick = {
                    vm.executeBatch(op, items); batchOp = null; selected.clear(); selecting = false
                }) { Text("تأیید و اجرا") }
            },
            dismissButton = { TextButton(onClick = { batchOp = null }) { Text("انصراف") } }
        )
    }

    Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("مدیریت برنامه‌ها", style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { selecting = !selecting; selected.clear() }) { Text(if (selecting) "پایان انتخاب" else "انتخاب چندتایی", fontSize = 12.sp) }
                Button(onClick = { vm.scan() }, enabled = !vm.loading && !vm.busy) { Text(if (vm.loading) "اسکن…" else "اسکن", fontSize = 12.sp) }
            }
        }
        if (vm.conn != Conn.CONNECTED) {
            Text("ADB داخلی وصل نیست؛ فعلاً فقط مشاهده ممکن است (تب «اتصال»).", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }
        if (vm.loading || vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        OutlinedTextField(
            value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, label = { Text("جست‌وجوی نام یا Package Name") }
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            filters.forEach { item ->
                FilterChip(selected = filter == item, onClick = { filter = item }, label = { Text(item, fontSize = 11.sp) })
            }
        }
        if (selecting) {
            Text("${selected.size} مورد انتخاب شده", style = MaterialTheme.typography.labelMedium)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = {
                    selected.clear()
                    selected.addAll(vm.apps.filter { it.risk == Risk.SAFE && it.isInstalled && it.isEnabled }.map { it.pkg })
                }) { Text("همه موارد امن", fontSize = 11.sp) }
                OutlinedButton(onClick = { selected.clear() }) { Text("پاک‌کردن", fontSize = 11.sp) }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(Op.DISABLE, Op.UNINSTALL_USER, Op.STANDBY_RESTRICT, Op.BG_RESTRICT).forEach { op ->
                    Button(
                        onClick = { batchOp = op },
                        enabled = selected.isNotEmpty() && vm.conn == Conn.CONNECTED && !vm.busy
                    ) { Text(op.title, fontSize = 11.sp) }
                }
            }
        }
        Text("نمایش ${visible.size} از ${vm.apps.size} بسته", style = MaterialTheme.typography.labelMedium)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(visible, key = { it.pkg }) { a ->
                ElevatedCard(Modifier.fillMaxWidth().clickable {
                    if (selecting) {
                        if (a.risk != Risk.PROTECTED) { if (a.pkg in selected) selected.remove(a.pkg) else selected.add(a.pkg) }
                    } else detailPkg = a.pkg
                }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (selecting && a.risk != Risk.PROTECTED) {
                            Checkbox(checked = a.pkg in selected, onCheckedChange = null)
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    (a.info?.let { Categories.emoji(it.icon) + " " } ?: "") + (a.info?.nameFa ?: a.label),
                                    style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f)
                                )
                                RiskBadge(a.risk)
                            }
                            Text(a.pkg, style = MaterialTheme.typography.bodySmall)
                            val state = when {
                                !a.isInstalled -> "حذف‌شده برای کاربر"
                                a.isEnabled -> "فعال"
                                else -> "غیرفعال"
                            }
                            Text("نسخه: ${a.versionName} • ${if (a.isSystem) "سیستمی" else "کاربر"} • $state", style = MaterialTheme.typography.labelSmall)
                            a.info?.let { i ->
                                if (i.descriptionFa.isNotBlank()) Text(i.descriptionFa, fontSize = 12.sp, maxLines = 2, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${i.action.label} • باتری: ${i.battery.label}", fontSize = 11.sp, color = riskColor(a.risk))
                            }
                        }
                    }
                }
            }
        }
        Text(
            "v0.5.1 • هر عملیات تأیید می‌گیرد، نتیجه‌اش بررسی و در سابقه ثبت می‌شود.",
            Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun riskColor(r: Risk): Color = when (r) {
    Risk.PROTECTED -> Color(0xFFEF5350)  // red
    Risk.CAUTION -> Color(0xFFFFCA28)    // yellow
    Risk.SAFE -> Color(0xFF66BB6A)       // green
    Risk.NORMAL -> MaterialTheme.colorScheme.onSurfaceVariant
}

@Composable
private fun RiskBadge(r: Risk) {
    val c = riskColor(r)
    Text(
        r.label, fontSize = 11.sp, color = c,
        modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(c.copy(alpha = 0.16f)).padding(horizontal = 8.dp, vertical = 2.dp)
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DetailDialog(app: AppItem, vm: MainViewModel, onPick: (Op) -> Unit, onClose: () -> Unit) {
    val i = app.info
    val ops = availableOps(app)
    // Disabling comes first: it is reversible and is the safe way to test before removing.
    val ordered = ops.sortedBy { if (it == Op.DISABLE) 0 else 1 }
    Dialog(onDismissRequest = onClose) {
        Card(Modifier.fillMaxWidth().heightIn(max = 620.dp)) {
            Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text((i?.let { Categories.emoji(it.icon) + " " } ?: "") + (i?.nameFa ?: app.label), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    RiskBadge(app.risk)
                }
                if (i != null && i.nameEn.isNotBlank()) Text(i.nameEn, style = MaterialTheme.typography.bodySmall)
                Text(app.pkg, style = MaterialTheme.typography.bodySmall)
                Text("نسخه: ${app.versionName} • ${if (app.isSystem) "سیستمی" else "کاربر"}", style = MaterialTheme.typography.labelSmall)
                if (i != null) {
                    Text("دسته: ${Categories.label(i.category)} • تأثیر روی باتری: ${i.battery.label}", style = MaterialTheme.typography.labelSmall)
                    if (i.descriptionFa.isNotBlank()) Text(i.descriptionFa, fontSize = 13.sp)
                    Text(i.action.label, color = riskColor(app.risk), style = MaterialTheme.typography.titleSmall)
                    if (i.sideEffects.isNotBlank()) Text("عوارض احتمالی: ${i.sideEffects}", fontSize = 12.sp)
                    i.osWarning(vm.device)?.let { Text(it, fontSize = 12.sp, color = Color(0xFFFFB74D)) }
                    if (!i.verified) Text("این توضیح از دیتابیس تقریبی است و با فهرست واقعی گوشی راستی‌آزمایی نشده.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Text("این بسته در دیتابیس نیست؛ ریسک آن «احتیاط» حساب می‌شود (بستهٔ سیستمی ناشناخته).", fontSize = 12.sp)
                }
                if (ordered.isEmpty()) {
                    Text("این برنامه برای ایمنی گوشی قفل است و هیچ عملیاتی روی آن انجام نمی‌شود.", fontSize = 12.sp, color = riskColor(Risk.PROTECTED))
                } else {
                    if (vm.conn != Conn.CONNECTED) Text("برای اجرا باید در تب «اتصال» ADB وصل باشد.", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ordered.forEachIndexed { idx, op ->
                            val enabled = vm.conn == Conn.CONNECTED && !vm.busy
                            if (idx == 0) Button(onClick = { onPick(op) }, enabled = enabled, contentPadding = PaddingValues(horizontal = 12.dp)) { Text(op.title, fontSize = 12.sp) }
                            else OutlinedButton(onClick = { onPick(op) }, enabled = enabled, contentPadding = PaddingValues(horizontal = 10.dp)) { Text(op.title, fontSize = 12.sp) }
                        }
                    }
                }
                TextButton(onClick = onClose, modifier = Modifier.align(Alignment.End)) { Text("بستن") }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AppearanceScreen(vm: MainViewModel, pad: PaddingValues) {
    val uri = LocalUriHandler.current
    var pending by remember { mutableStateOf<Pair<AppearanceTool, Boolean>?>(null) } // tool to "turn on?"

    pending?.let { (tool, on) ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text(if (on) "اعمال: ${tool.nameFa}" else "بازگشت: ${tool.nameFa}") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (on) "دستورهایی که به‌ترتیب اجرا می‌شود:" else "مقدار قبلی برگردانده می‌شود (اگر ذخیره نشده باشد، مقدار «خاموش» ابزار):", style = MaterialTheme.typography.labelMedium)
                    tool.commands.forEach { Text(AppearanceRunner.shellCommand(it.prop, if (on) it.value else it.off), fontSize = 10.sp) }
                    if (on && tool.powerWarning) Text(tool.warningFa, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    if (on) tool.osWarning(vm.device)?.let { Text(it, fontSize = 12.sp, color = Color(0xFFFFB74D)) }
                    Text("بعد از اجرا مقدار با getprop بررسی می‌شود و نتیجه در «سابقه» ثبت می‌شود.", fontSize = 12.sp)
                    if (on) tool.needsText?.let { Text(it, fontSize = 12.sp) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (on) vm.applyTool(tool) else vm.revertTool(tool)
                    pending = null
                }) { Text("تأیید و اجرا") }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("انصراف") } }
        )
    }

    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("ابزارهای ظاهر HyperOS", style = MaterialTheme.typography.titleLarge)
        Text("${vm.device.androidText} • HyperOS ${vm.device.hyperosText}", style = MaterialTheme.typography.labelMedium)
        Text("روش اجرا مثل ویدئو: سرویس سیستمی شیائومی (miui.mqsas) برای setprop. بعد از اجرا چند ثانیه صبر می‌کند و مقدار را با getprop بررسی می‌کند؛ اگر اعمال نشد پیام می‌دهد.", fontSize = 12.sp)
        if (vm.conn != Conn.CONNECTED) Text("ADB داخلی وصل نیست؛ برای اجرا به تب «اتصال» برو.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.toolDb.tools.forEach { tool ->
            val applied = vm.toolStatus[tool.id] == true
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(tool.nameFa, style = MaterialTheme.typography.titleMedium)
                            if (tool.nameEn.isNotBlank()) Text(tool.nameEn, style = MaterialTheme.typography.bodySmall)
                        }
                        if (tool.runnable) {
                            Switch(
                                checked = applied,
                                onCheckedChange = { on -> pending = tool to on },
                                enabled = vm.conn == Conn.CONNECTED && !vm.busy
                            )
                        }
                    }
                    Text(tool.descriptionFa, fontSize = 12.sp)
                    if (tool.runnable) {
                        tool.commands.forEach { Text("${it.prop} = ${it.value}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        Text(
                            if (vm.toolStatus.containsKey(tool.id)) (if (applied) "وضعیت فعلی: اعمال‌شده" else "وضعیت فعلی: اعمال نشده") else "وضعیت فعلی: بعد از اتصال ADB بررسی می‌شود",
                            fontSize = 11.sp, color = if (applied) riskColor(Risk.SAFE) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        tool.needsText?.let { Text(it, fontSize = 11.sp) }
                        tool.osWarning(vm.device)?.let { Text(it, fontSize = 11.sp, color = Color(0xFFFFB74D)) }
                    } else {
                        Text("به‌زودی", fontSize = 11.sp, color = Color(0xFFFFB74D))
                    }
                    if (tool.warningFa.isNotBlank()) Text(tool.warningFa, fontSize = 11.sp, color = if (tool.powerWarning) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                    if (applied) {
                        OutlinedButton(onClick = { pending = tool to false }, enabled = vm.conn == Conn.CONNECTED && !vm.busy) { Text("بازگشت (Reset)", fontSize = 12.sp) }
                    }
                }
            }
        }
        if (vm.toolDb.links.isNotEmpty()) {
            Text("لینک‌ها", style = MaterialTheme.typography.titleSmall)
            vm.toolDb.links.forEach { l ->
                TextButton(onClick = { runCatching { uri.openUri(l.url) } }) { Text(l.title, fontSize = 12.sp) }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DiagScreen(vm: MainViewModel, pad: PaddingValues) {
    var pending by remember { mutableStateOf<Pair<Op, AppItem>?>(null) }
    ConfirmDialog(pending, vm) { pending = null }
    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let { vm.importDb(it) } }
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("دستگاه و دیتابیس", style = MaterialTheme.typography.titleSmall)
                Text("${vm.device.model} • ${vm.device.androidText} • HyperOS ${vm.device.hyperosText}", fontSize = 12.sp)
                Text("دیتابیس بسته‌ها: ${vm.packageDb.entries.size} رکورد • نسخه ${vm.packageDb.version}${if (vm.packageDb.fromOverride) " (واردشده)" else ""}", fontSize = 12.sp)
                Text("ابزارهای ظاهر: ${vm.toolDb.tools.size} مورد • نسخه ${vm.toolDb.version}", fontSize = 12.sp)
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }, enabled = !vm.busy) {
                    Text("به‌روزرسانی دیتابیس از فایل JSON", fontSize = 12.sp)
                }
            }
        }
        Text("تشخیص داغی و لگ", style = MaterialTheme.typography.titleLarge)
        Text("برنامه‌های پرمصرف CPU در چند دقیقهٔ اخیر و دمای باتری. بهتر است وقتی گوشی داغ یا کند است اجرا کنی.", fontSize = 12.sp)
        Button(onClick = { vm.diagnose() }, enabled = vm.conn == Conn.CONNECTED && !vm.busy) { Text("اجرای تشخیص") }
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.diag?.let { d ->
            Text(
                "دمای باتری: ${d.tempC?.let { "%.1f".format(it) } ?: "نامشخص"}°C • شارژ: ${d.level?.toString() ?: "نامشخص"}٪",
                style = MaterialTheme.typography.titleSmall
            )
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(d.rows) { r ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(r.app?.label ?: r.proc, style = MaterialTheme.typography.titleSmall)
                            Text("${r.proc} • CPU: ${"%.1f".format(r.cpu)}٪", style = MaterialTheme.typography.bodySmall)
                            val a = r.app
                            if (a == null) {
                                Text("فرایند سیستمی یا ناشناس؛ عملیاتی برایش ارائه نمی‌شود.", fontSize = 11.sp)
                            } else if (a.risk == Risk.PROTECTED) {
                                Text("برنامهٔ محافظت‌شده.", fontSize = 11.sp)
                            } else {
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf(Op.STANDBY_RESTRICT, Op.BG_RESTRICT, Op.DISABLE, Op.UNINSTALL_USER)
                                        .filter { it in availableOps(a) }
                                        .forEach { op ->
                                            OutlinedButton(onClick = { pending = op to a }, enabled = !vm.busy, contentPadding = PaddingValues(horizontal = 10.dp)) {
                                                Text(op.title, fontSize = 12.sp)
                                            }
                                        }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(vm: MainViewModel, pad: PaddingValues) {
    val ctx = LocalContext.current
    val fmt = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US) }
    var confirm by remember { mutableStateOf<String?>(null) }

    confirm?.let { kind ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(if (kind == "restore") "بازگردانی همه" else "اعمال مجدد") },
            text = {
                Text(
                    if (kind == "restore") "همهٔ تغییرات ثبت‌شده توسط این برنامه (غیرفعال‌سازی، حذف، محدودسازی‌ها) به حالت قبل برمی‌گردد. ${vm.profileSize()} مورد بررسی می‌شود."
                    else "تغییرات ثبت‌شده دوباره اعمال می‌شود (مثلاً بعد از آپدیت سیستم). ${vm.profileSize()} مورد بررسی می‌شود."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (kind == "restore") vm.restoreAll() else vm.reapplyAll()
                    confirm = null
                }) { Text("تأیید و اجرا") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("انصراف") } }
        )
    }

    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("سابقهٔ عملیات", style = MaterialTheme.typography.titleLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { confirm = "restore" }, enabled = vm.conn == Conn.CONNECTED && !vm.busy) { Text("بازگردانی همه", fontSize = 12.sp) }
            OutlinedButton(onClick = { confirm = "reapply" }, enabled = vm.conn == Conn.CONNECTED && !vm.busy) { Text("اعمال مجدد", fontSize = 12.sp) }
            OutlinedButton(onClick = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, vm.report())
                }
                runCatching { ctx.startActivity(Intent.createChooser(send, "گزارش")) }
            }) { Text("اشتراک‌گذاری گزارش", fontSize = 12.sp) }
        }
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (vm.history.isEmpty()) Text("هنوز عملیاتی انجام نشده است.")
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.history) { e ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${e.op.title} • ${e.label}", style = MaterialTheme.typography.titleSmall)
                        Text(e.pkg, style = MaterialTheme.typography.bodySmall)
                        Text(
                            "${fmt.format(Date(e.time))} • ${if (e.ok) "موفق" else "ناموفق"}" + if (!e.ok) " — ${e.msg}" else "",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (e.ok) Color(0xFF66BB6A) else MaterialTheme.colorScheme.error
                        )
                        val u = e.op.undo
                        if (e.ok && u != null) {
                            OutlinedButton(onClick = { vm.undo(e) }, enabled = !vm.busy && vm.conn == Conn.CONNECTED) {
                                Text("بازگردانی (${u.title})", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
