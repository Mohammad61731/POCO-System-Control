package com.poco.systemcontrol

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AppRoot(vm)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshConn()
    }
}

@Composable
private fun AppRoot(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(if (vm.conn == Conn.CONNECTED) 1 else 0) }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        vm.message?.let {
            snack.showSnackbar(it)
            vm.message = null
        }
    }
    val names = listOf("اتصال", "برنامه‌ها", "تشخیص", "سابقه")
    val icons = listOf("⌁", "▦", "🌡", "☰")
    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                names.forEachIndexed { i, n ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(icons[i]) }, label = { Text(n, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { pad ->
        when (tab) {
            0 -> ConnectScreen(vm, pad)
            1 -> AppsScreen(vm, pad)
            2 -> DiagScreen(vm, pad)
            else -> HistoryScreen(vm, pad)
        }
    }
}

@Composable
private fun ConnectScreen(vm: MainViewModel, pad: PaddingValues) {
    val ctx = LocalContext.current
    var code by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { vm.startPairingDiscovery() }
    DisposableEffect(Unit) { onDispose { vm.stopPairingDiscovery() } }

    fun openDevSettings() {
        runCatching { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            PairingHelper.showNotification(ctx, "کد ۶ رقمی را اینجا بنویس", withInput = true)
            openDevSettings()
        } else vm.message = "برای جفت‌سازی با نوتیفیکیشن، اجازهٔ اعلان لازم است"
    }

    Column(
        Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("POCO SYSTEM CONTROL", style = MaterialTheme.typography.labelLarge)
        Text("اتصال ADB داخلی", style = MaterialTheme.typography.headlineSmall)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Text(
                if (vm.conn == Conn.CONNECTED) "● وصل است — می‌توانی در تب «برنامه‌ها» کار کنی" else "○ وصل نیست",
                Modifier.padding(16.dp),
                color = if (vm.conn == Conn.CONNECTED) Color(0xFF66BB6A) else MaterialTheme.colorScheme.error
            )
        }
        Text(
            "فقط یک‌بار لازم است:\n" +
                "۱) گوشی را به یک Wi‑Fi وصل کن (اینترنت لازم نیست).\n" +
                "۲) «اشکال‌زدایی بی‌سیم» را روشن کن.\n" +
                "۳) روش پیشنهادی: دکمهٔ «جفت‌سازی با نوتیفیکیشن» را بزن، در تنظیمات «جفت‌سازی با کد» را باز کن، کد ۶ رقمی را در نوتیفیکیشن بنویس و «ارسال» بزن.\n" +
                "۴) روش دستی: برنامه را در پنجرهٔ شناور/صفحهٔ تقسیم‌شده باز نگه دار، کد را پایین بنویس و «جفت‌سازی» بزن.\n" +
                "۵) بعد روی «اتصال» بزن. بعد از ریستارت فقط Wireless debugging را دوباره روشن کن.",
            style = MaterialTheme.typography.bodyMedium
        )
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= 33 &&
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                PairingHelper.showNotification(ctx, "کد ۶ رقمی را اینجا بنویس", withInput = true)
                openDevSettings()
            }
        }) { Text("جفت‌سازی با نوتیفیکیشن") }
        OutlinedButton(onClick = { openDevSettings() }) { Text("باز کردن گزینه‌های توسعه‌دهنده") }
        OutlinedTextField(
            value = vm.pairingPort, onValueChange = { vm.pairingPort = it.filter(Char::isDigit) },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("پورت جفت‌سازی (خودکار)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        OutlinedTextField(
            value = code, onValueChange = { code = it.filter(Char::isDigit).take(6) },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("کد جفت‌سازی (۶ رقم) — روش دستی") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.pair(code) }, enabled = !vm.busy) { Text("جفت‌سازی") }
            Button(onClick = { vm.connect() }, enabled = !vm.busy) { Text("اتصال") }
        }
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    }
}

@Composable
private fun ConfirmDialog(pending: Pair<Op, AppItem>?, vm: MainViewModel, onClose: () -> Unit) {
    pending?.let { (op, app) ->
        AlertDialog(
            onDismissRequest = onClose,
            title = { Text(op.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(app.label, style = MaterialTheme.typography.titleSmall)
                    Text(app.pkg, style = MaterialTheme.typography.bodySmall)
                    Text("دستوری که اجرا می‌شود:", style = MaterialTheme.typography.labelMedium)
                    Text(commandFor(op, app.pkg), fontSize = 11.sp)
                    if (app.risk == Risk.CAUTION) Text("این بستهٔ سیستمی ناشناخته است؛ مطمئن شو نقشش را می‌دانی.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    if (op == Op.UNINSTALL_USER) Text("حذف فقط برای کاربر فعلی است و با «بازگردانی» برمی‌گردد.", fontSize = 12.sp)
                    if (op == Op.UNINSTALL_FULL) Text("داده‌های برنامه هم پاک می‌شود و برگشت ندارد.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { vm.execute(op, app); onClose() }) { Text("تأیید و اجرا") } },
            dismissButton = { TextButton(onClick = onClose) { Text("انصراف") } }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AppsScreen(vm: MainViewModel, pad: PaddingValues) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("همه") }
    var expanded by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<Pair<Op, AppItem>?>(null) }
    var selecting by remember { mutableStateOf(false) }
    var batchOp by remember { mutableStateOf<Op?>(null) }
    val selected = remember { mutableStateListOf<String>() }
    val filters = listOf("همه", "برای بررسی", "سیستمی", "کاربر", "غیرفعال", "حذف‌شده")

    val visible = remember(vm.apps, query, filter) {
        vm.apps.filter { a ->
            val q = query.isBlank() || a.label.contains(query, true) || a.pkg.contains(query, true)
            val f = when (filter) {
                "برای بررسی" -> a.risk == Risk.REVIEW
                "سیستمی" -> a.isSystem
                "کاربر" -> !a.isSystem
                "غیرفعال" -> a.isInstalled && !a.isEnabled
                "حذف‌شده" -> !a.isInstalled
                else -> true
            }
            q && f
        }
    }

    ConfirmDialog(pending, vm) { pending = null }

    batchOp?.let { op ->
        val items = vm.apps.filter { it.pkg in selected && op in availableOps(it) }
        AlertDialog(
            onDismissRequest = { batchOp = null },
            title = { Text("${op.title} — ${items.size} برنامه") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (items.isEmpty()) Text("هیچ‌کدام از موارد انتخابی برای این عملیات مناسب نیستند.")
                    items.take(25).forEach { Text("• ${it.label}", fontSize = 13.sp) }
                    if (items.size > 25) Text("و ${items.size - 25} مورد دیگر…", fontSize = 12.sp)
                    Text("برنامه‌های محافظت‌شده و مواردی که از قبل در این وضعیت‌اند حذف شده‌اند.", fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(enabled = items.isNotEmpty(), onClick = {
                    vm.executeBatch(op, items); batchOp = null; selected.clear(); selecting = false
                }) { Text("تأیید و اجرا") }
            },
            dismissButton = { TextButton(onClick = { batchOp = null }) { Text("انصراف") } }
        )
    }

    Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("مدیریت برنامه‌ها", style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { selecting = !selecting; selected.clear() }) { Text(if (selecting) "پایان انتخاب" else "انتخاب چندتایی", fontSize = 12.sp) }
                Button(onClick = { vm.scan() }, enabled = !vm.loading && !vm.busy) { Text(if (vm.loading) "اسکن…" else "اسکن", fontSize = 12.sp) }
            }
        }
        if (vm.conn != Conn.CONNECTED) {
            Text("ADB داخلی وصل نیست؛ فعلاً فقط مشاهده ممکن است (تب «اتصال»).", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }
        if (vm.loading || vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        OutlinedTextField(
            value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, label = { Text("جست‌وجوی نام یا Package Name") }
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            filters.forEach { item ->
                FilterChip(selected = filter == item, onClick = { filter = item }, label = { Text(item, fontSize = 11.sp) })
            }
        }
        if (selecting) {
            Text("${selected.size} مورد انتخاب شده", style = MaterialTheme.typography.labelMedium)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = {
                    selected.clear()
                    selected.addAll(vm.apps.filter { it.risk == Risk.REVIEW && it.isInstalled }.map { it.pkg })
                }) { Text("انتخاب «برای بررسی»", fontSize = 11.sp) }
                OutlinedButton(onClick = { selected.clear() }) { Text("پاک‌کردن", fontSize = 11.sp) }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(Op.DISABLE, Op.UNINSTALL_USER, Op.STANDBY_RESTRICT, Op.BG_RESTRICT).forEach { op ->
                    Button(
                        onClick = { batchOp = op },
                        enabled = selected.isNotEmpty() && vm.conn == Conn.CONNECTED && !vm.busy
                    ) { Text(op.title, fontSize = 11.sp) }
                }
            }
        }
        Text("نمایش ${visible.size} از ${vm.apps.size} بسته", style = MaterialTheme.typography.labelMedium)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(visible, key = { it.pkg }) { a ->
                ElevatedCard(Modifier.fillMaxWidth().clickable {
                    if (selecting) {
                        if (a.risk != Risk.PROTECTED) { if (a.pkg in selected) selected.remove(a.pkg) else selected.add(a.pkg) }
                    } else expanded = if (expanded == a.pkg) null else a.pkg
                }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (selecting && a.risk != Risk.PROTECTED) {
                            Checkbox(checked = a.pkg in selected, onCheckedChange = null)
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(a.label, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                Text(a.risk.label, style = MaterialTheme.typography.labelSmall, color = riskColor(a.risk))
                            }
                            Text(a.pkg, style = MaterialTheme.typography.bodySmall)
                            val state = when {
                                !a.isInstalled -> "حذف‌شده برای کاربر"
                                a.isEnabled -> "فعال"
                                else -> "غیرفعال"
                            }
                            Text("نسخه: ${a.versionName} • ${if (a.isSystem) "سیستمی" else "کاربر"} • $state", style = MaterialTheme.typography.labelSmall)
                            if (expanded == a.pkg && !selecting) {
                                Safety.hints[a.pkg]?.let { Text("$it (توضیح تقریبی)", fontSize = 12.sp) }
                                val ops = availableOps(a)
                                if (ops.isEmpty()) {
                                    Text("این برنامه برای ایمنی گوشی قفل است و هیچ عملیاتی روی آن انجام نمی‌شود.", fontSize = 12.sp)
                                } else {
                                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        ops.forEach { op ->
                                            OutlinedButton(
                                                onClick = { pending = op to a },
                                                enabled = vm.conn == Conn.CONNECTED && !vm.busy,
                                                contentPadding = PaddingValues(horizontal = 10.dp)
                                            ) { Text(op.title, fontSize = 12.sp) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Text(
            "v0.4.0 • هر عملیات تأیید می‌گیرد، نتیجه‌اش بررسی و در سابقه ثبت می‌شود.",
            Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun riskColor(r: Risk): Color = when (r) {
    Risk.PROTECTED -> MaterialTheme.colorScheme.error
    Risk.CAUTION -> Color(0xFFFFB74D)
    Risk.REVIEW -> MaterialTheme.colorScheme.tertiary
    Risk.NORMAL -> MaterialTheme.colorScheme.onSurfaceVariant
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DiagScreen(vm: MainViewModel, pad: PaddingValues) {
    var pending by remember { mutableStateOf<Pair<Op, AppItem>?>(null) }
    ConfirmDialog(pending, vm) { pending = null }
    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("تشخیص داغی و لگ", style = MaterialTheme.typography.titleLarge)
        Text("برنامه‌های پرمصرف CPU در چند دقیقهٔ اخیر و دمای باتری. بهتر است وقتی گوشی داغ یا کند است اجرا کنی.", fontSize = 12.sp)
        Button(onClick = { vm.diagnose() }, enabled = vm.conn == Conn.CONNECTED && !vm.busy) { Text("اجرای تشخیص") }
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.diag?.let { d ->
            Text(
                "دمای باتری: ${d.tempC?.let { "%.1f".format(it) } ?: "نامشخص"}°C • شارژ: ${d.level?.toString() ?: "نامشخص"}٪",
                style = MaterialTheme.typography.titleSmall
            )
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(d.rows) { r ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(r.app?.label ?: r.proc, style = MaterialTheme.typography.titleSmall)
                            Text("${r.proc} • CPU: ${"%.1f".format(r.cpu)}٪", style = MaterialTheme.typography.bodySmall)
                            val a = r.app
                            if (a == null) {
                                Text("فرایند سیستمی یا ناشناس؛ عملیاتی برایش ارائه نمی‌شود.", fontSize = 11.sp)
                            } else if (a.risk == Risk.PROTECTED) {
                                Text("برنامهٔ محافظت‌شده.", fontSize = 11.sp)
                            } else {
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf(Op.STANDBY_RESTRICT, Op.BG_RESTRICT, Op.DISABLE, Op.UNINSTALL_USER)
                                        .filter { it in availableOps(a) }
                                        .forEach { op ->
                                            OutlinedButton(onClick = { pending = op to a }, enabled = !vm.busy, contentPadding = PaddingValues(horizontal = 10.dp)) {
                                                Text(op.title, fontSize = 12.sp)
                                            }
                                        }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(vm: MainViewModel, pad: PaddingValues) {
    val ctx = LocalContext.current
    val fmt = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US) }
    var confirm by remember { mutableStateOf<String?>(null) }

    confirm?.let { kind ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(if (kind == "restore") "بازگردانی همه" else "اعمال مجدد") },
            text = {
                Text(
                    if (kind == "restore") "همهٔ تغییرات ثبت‌شده توسط این برنامه (غیرفعال‌سازی، حذف، محدودسازی‌ها) به حالت قبل برمی‌گردد. ${vm.profileSize()} مورد بررسی می‌شود."
                    else "تغییرات ثبت‌شده دوباره اعمال می‌شود (مثلاً بعد از آپدیت سیستم). ${vm.profileSize()} مورد بررسی می‌شود."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (kind == "restore") vm.restoreAll() else vm.reapplyAll()
                    confirm = null
                }) { Text("تأیید و اجرا") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("انصراف") } }
        )
    }

    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("سابقهٔ عملیات", style = MaterialTheme.typography.titleLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { confirm = "restore" }, enabled = vm.conn == Conn.CONNECTED && !vm.busy) { Text("بازگردانی همه", fontSize = 12.sp) }
            OutlinedButton(onClick = { confirm = "reapply" }, enabled = vm.conn == Conn.CONNECTED && !vm.busy) { Text("اعمال مجدد", fontSize = 12.sp) }
            OutlinedButton(onClick = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, vm.report())
                }
                runCatching { ctx.startActivity(Intent.createChooser(send, "گزارش")) }
            }) { Text("اشتراک‌گذاری گزارش", fontSize = 12.sp) }
        }
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (vm.history.isEmpty()) Text("هنوز عملیاتی انجام نشده است.")
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.history) { e ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${e.op.title} • ${e.label}", style = MaterialTheme.typography.titleSmall)
                        Text(e.pkg, style = MaterialTheme.typography.bodySmall)
                        Text(
                            "${fmt.format(Date(e.time))} • ${if (e.ok) "موفق" else "ناموفق"}" + if (!e.ok) " — ${e.msg}" else "",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (e.ok) Color(0xFF66BB6A) else MaterialTheme.colorScheme.error
                        )
                        val u = e.op.undo
                        if (e.ok && u != null) {
                            OutlinedButton(onClick = { vm.undo(e) }, enabled = !vm.busy && vm.conn == Conn.CONNECTED) {
                                Text("بازگردانی (${u.title})", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
