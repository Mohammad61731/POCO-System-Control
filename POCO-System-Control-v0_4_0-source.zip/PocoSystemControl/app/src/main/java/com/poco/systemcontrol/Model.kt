package com.poco.systemcontrol

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

enum class Risk(val label: String) {
    PROTECTED("ممنوع"),
    CAUTION("احتیاط"),
    SAFE("امن"),
    NORMAL("عادی")
}

data class AppItem(
    val label: String,
    val pkg: String,
    val versionName: String,
    val isSystem: Boolean,
    val isEnabled: Boolean,
    val isInstalled: Boolean,
    val hasUpdate: Boolean,
    val risk: Risk,
    val info: PkgInfo? = null
)

/** Every action the app can perform is one of these typed operations. No free-text commands exist. */
enum class Op(val title: String, val destructive: Boolean) {
    DISABLE("غیرفعال‌سازی", false),
    ENABLE("فعال‌سازی", false),
    UNINSTALL_USER("حذف برنامه", true),
    UNINSTALL_FULL("حذف کامل (با داده)", true),
    RESTORE("بازگردانی حذف‌شده", false),
    REMOVE_UPDATES("حذف آپدیت‌ها", true),
    BG_RESTRICT("محدودکردن پس‌زمینه", false),
    BG_ALLOW("آزادکردن پس‌زمینه", false),
    STANDBY_RESTRICT("محدودسازی Standby", false),
    STANDBY_RESET("آزادسازی Standby", false),
    DOZE_ON("حذف از لیست مجاز باتری", false),
    DOZE_OFF("افزودن به لیست مجاز باتری", false),
    FORCE_STOP("توقف اجباری", false),
    TOOL_APPLY("اعمال ابزار ظاهر", false),
    TOOL_REVERT("بازگشت ابزار ظاهر", false)
}

val Op.undo: Op?
    get() = when (this) {
        Op.DISABLE -> Op.ENABLE
        Op.ENABLE -> Op.DISABLE
        Op.UNINSTALL_USER -> Op.RESTORE
        Op.RESTORE -> Op.UNINSTALL_USER
        Op.BG_RESTRICT -> Op.BG_ALLOW
        Op.BG_ALLOW -> Op.BG_RESTRICT
        Op.STANDBY_RESTRICT -> Op.STANDBY_RESET
        Op.STANDBY_RESET -> Op.STANDBY_RESTRICT
        Op.DOZE_ON -> Op.DOZE_OFF
        Op.DOZE_OFF -> Op.DOZE_ON
        Op.TOOL_APPLY -> Op.TOOL_REVERT
        Op.TOOL_REVERT -> Op.TOOL_APPLY
        else -> null
    }

/** Operations that "apply" a restriction (used for restore-all / reapply). */
val applyingOps = setOf(Op.DISABLE, Op.UNINSTALL_USER, Op.BG_RESTRICT, Op.STANDBY_RESTRICT, Op.DOZE_ON)

val Op.group: String
    get() = when (this) {
        Op.DISABLE, Op.ENABLE, Op.UNINSTALL_USER, Op.RESTORE -> "state"
        Op.BG_RESTRICT, Op.BG_ALLOW -> "bg"
        Op.STANDBY_RESTRICT, Op.STANDBY_RESET -> "standby"
        Op.DOZE_ON, Op.DOZE_OFF -> "doze"
        else -> name
    }

fun commandFor(op: Op, pkg: String): String = when (op) {
    Op.DISABLE -> "pm disable-user --user 0 $pkg"
    Op.ENABLE -> "pm enable --user 0 $pkg"
    Op.UNINSTALL_USER -> "pm uninstall -k --user 0 $pkg"
    Op.UNINSTALL_FULL -> "pm uninstall --user 0 $pkg"
    Op.RESTORE -> "cmd package install-existing --user 0 $pkg"
    Op.REMOVE_UPDATES -> "pm uninstall-system-updates $pkg"
    Op.BG_RESTRICT -> "cmd appops set $pkg RUN_ANY_IN_BACKGROUND ignore; cmd appops set $pkg RUN_IN_BACKGROUND ignore"
    Op.BG_ALLOW -> "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow; cmd appops set $pkg RUN_IN_BACKGROUND allow"
    Op.STANDBY_RESTRICT -> "am set-standby-bucket $pkg restricted"
    Op.STANDBY_RESET -> "am set-standby-bucket $pkg active"
    Op.DOZE_ON -> "cmd deviceidle whitelist -$pkg"
    Op.DOZE_OFF -> "cmd deviceidle whitelist +$pkg"
    Op.FORCE_STOP -> "am force-stop $pkg"
    Op.TOOL_APPLY, Op.TOOL_REVERT -> "" // appearance tools run through AppearanceRunner, never through commandFor
}

fun availableOps(a: AppItem): List<Op> = when {
    a.risk == Risk.PROTECTED -> emptyList()
    !a.isInstalled -> listOf(Op.RESTORE)
    else -> buildList {
        add(if (a.isEnabled) Op.DISABLE else Op.ENABLE)
        add(Op.UNINSTALL_USER)
        if (!a.isSystem) add(Op.UNINSTALL_FULL)
        if (a.isSystem && a.hasUpdate) add(Op.REMOVE_UPDATES)
        add(Op.STANDBY_RESTRICT)
        add(Op.BG_RESTRICT)
        add(Op.DOZE_ON)
        add(Op.STANDBY_RESET)
        add(Op.BG_ALLOW)
        add(Op.DOZE_OFF)
        add(Op.FORCE_STOP)
    }
}

object Safety {
    private val pkgRegex = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")

    fun isValid(pkg: String) = pkgRegex.matches(pkg)

    private val protectedExact = setOf(
        "android", "com.android.systemui", "com.android.phone", "com.android.settings",
        "com.android.server.telecom", "com.android.shell", "com.android.vending",
        "com.android.updater", "com.miui.home", "com.miui.securitycenter",
        "com.miui.powerkeeper", "com.miui.core", "com.miui.system", "com.xiaomi.xmsf"
    )

    private val protectedPrefixes = listOf(
        "android.", "com.android.providers.", "com.android.permissioncontroller",
        "com.google.android.permissioncontroller", "com.android.packageinstaller",
        "com.google.android.packageinstaller", "com.android.thermal", "com.miui.thermal",
        "com.xiaomi.thermal", "com.google.android.gms", "com.google.android.gsf",
        "com.android.networkstack", "com.android.bluetooth", "com.android.nfc",
        "com.android.inputmethod", "com.google.android.inputmethod", "com.android.keychain",
        "com.android.certinstaller", "com.android.cellbroadcast", "com.android.ims",
        "com.android.stk", "com.android.mms.service", "com.android.carrierconfig",
        "com.android.location", "com.android.wifi", "com.android.connectivity",
        "com.android.modules", "com.google.android.modulemetadata", "com.google.android.webview",
        "com.android.webview", "com.android.launcher", "com.mi.android.globallauncher",
        "com.qualcomm", "com.qti", "com.mediatek", "org.codeaurora", "vendor.",
        "com.xiaomi.biometric", "com.miui.biometric", "com.android.se",
        "com.android.internal.", "com.google.android.marvin.", "com.google.android.accessibility",
        "com.miui.packageinstaller"
    )

    fun isProtected(pkg: String, self: String): Boolean =
        pkg == self || pkg in protectedExact || protectedPrefixes.any { pkg.startsWith(it) }
}

@Suppress("DEPRECATION")
fun loadApps(pm: PackageManager, self: String, db: PackageDb): List<AppItem> =
    pm.getInstalledPackages(PackageManager.MATCH_UNINSTALLED_PACKAGES).mapNotNull { info ->
        val ai = info.applicationInfo ?: return@mapNotNull null
        val pkg = info.packageName
        val label = runCatching { pm.getApplicationLabel(ai).toString() }.getOrDefault(pkg)
        val updated = (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 || updated
        val meta = db.find(pkg)
        // Code-level protection always wins; the database can only add restrictions, never remove them.
        val risk = when {
            Safety.isProtected(pkg, self) -> Risk.PROTECTED
            meta?.risk == DbRisk.DANGEROUS -> Risk.PROTECTED
            meta?.risk == DbRisk.SAFE -> Risk.SAFE
            meta?.risk == DbRisk.CAUTION -> Risk.CAUTION
            !system -> Risk.NORMAL
            else -> Risk.CAUTION // unknown system packages default to Caution
        }
        AppItem(
            label = label.ifBlank { pkg },
            pkg = pkg,
            versionName = info.versionName ?: "نامشخص",
            isSystem = system,
            isEnabled = ai.enabled,
            isInstalled = (ai.flags and ApplicationInfo.FLAG_INSTALLED) != 0,
            hasUpdate = updated,
            risk = risk,
            info = meta
        )
    }.sortedBy { it.label.lowercase() }
