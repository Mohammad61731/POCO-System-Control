package com.poco.systemcontrol

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// ---------------------------------------------------------------------------------------------
// Package database (assets/packages_db.json). Updating it needs no code change: the same file can
// be imported from inside the app. The database can only ADD caution; it can never unlock a package
// that Safety.isProtected() blocks.
// ---------------------------------------------------------------------------------------------

enum class DbRisk { SAFE, CAUTION, DANGEROUS }

enum class DbAction(val label: String) {
    REMOVE("پیشنهاد: حذف"),
    DISABLE("پیشنهاد: غیرفعال‌سازی"),
    KEEP("پیشنهاد: دست نزن")
}

enum class Battery(val label: String) { LOW("کم"), MEDIUM("متوسط"), HIGH("زیاد") }

data class OsSupport(val androidMin: Int?, val androidMax: Int?, val hyperos: List<Double>)

data class PkgInfo(
    val pkg: String,
    val nameFa: String,
    val nameEn: String,
    val descriptionFa: String,
    val category: String,
    val risk: DbRisk,
    val battery: Battery,
    val action: DbAction,
    val sideEffects: String,
    val os: OsSupport,
    val devices: List<String>,
    val icon: String,
    val altPackages: List<String>,
    val verified: Boolean
)

object Categories {
    private val fa = mapOf(
        "ads" to "تبلیغات", "analytics" to "آنالیتیکس", "cloud" to "ابر و حساب", "games" to "بازی",
        "media" to "رسانه", "system" to "سیستمی", "tools" to "ابزار", "store" to "فروشگاه",
        "social" to "شبکهٔ اجتماعی", "google" to "گوگل", "ai" to "هوش مصنوعی"
    )
    private val emoji = mapOf(
        "ads" to "📢", "analytics" to "📊", "cloud" to "☁️", "games" to "🎮", "media" to "🎬",
        "system" to "⚙️", "tools" to "🧰", "store" to "🛍", "social" to "💬", "google" to "🔎",
        "ai" to "✨", "shield" to "🛡"
    )

    fun label(slug: String) = fa[slug] ?: slug
    fun emoji(icon: String) = emoji[icon] ?: "📦"
}

class PackageDb(val version: String, val entries: List<PkgInfo>, val fromOverride: Boolean = false) {
    private val index: Map<String, PkgInfo> = HashMap<String, PkgInfo>().also { m ->
        entries.forEach { m[it.pkg] = it }
        // alternative package names (renamed across versions) point to the same record
        entries.forEach { e -> e.altPackages.forEach { alt -> if (alt !in m) m[alt] = e } }
    }

    fun find(pkg: String): PkgInfo? = index[pkg]

    companion object {
        const val ASSET = "packages_db.json"
        const val FILE = "packages_db.json"
        val EMPTY = PackageDb("-", emptyList())

        private inline fun <reified E : Enum<E>> enumOf(s: String, default: E): E =
            enumValues<E>().firstOrNull { it.name.equals(s, ignoreCase = true) } ?: default

        /** Throws when the text is not a usable packages database. */
        fun parse(text: String, fromOverride: Boolean = false): PackageDb {
            val root = JSONObject(text)
            require(root.optString("kind") == "packages") { "kind" }
            val arr = root.getJSONArray("packages")
            val list = ArrayList<PkgInfo>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val pkg = o.optString("package")
                if (!Safety.isValid(pkg)) continue
                val osObj = o.optJSONObject("osSupport")
                val os = OsSupport(
                    androidMin = osObj?.takeIf { it.has("androidMin") }?.optInt("androidMin"),
                    androidMax = osObj?.takeIf { it.has("androidMax") }?.optInt("androidMax"),
                    hyperos = osObj?.optJSONArray("hyperosVersions").doubles()
                )
                list += PkgInfo(
                    pkg = pkg,
                    nameFa = o.optString("nameFa").ifBlank { pkg },
                    nameEn = o.optString("nameEn"),
                    descriptionFa = o.optString("descriptionFa"),
                    category = o.optString("category", "system"),
                    risk = enumOf(o.optString("risk"), DbRisk.CAUTION),
                    battery = enumOf(o.optString("batteryImpact"), Battery.LOW),
                    action = enumOf(o.optString("action"), DbAction.KEEP),
                    sideEffects = o.optString("sideEffects"),
                    os = os,
                    devices = o.optJSONArray("devices").strings(),
                    icon = o.optString("icon").ifBlank { o.optString("category", "system") },
                    altPackages = o.optJSONArray("altPackages").strings().filter { Safety.isValid(it) },
                    verified = o.optBoolean("verified", false)
                )
            }
            require(list.isNotEmpty()) { "empty" }
            return PackageDb(root.optString("dbVersion", "0"), list, fromOverride)
        }

        /** Highest dbVersion wins between the bundled asset and an imported override file. */
        fun load(ctx: Context): PackageDb {
            val asset = JsonStore.asset(ctx, ASSET)
            val over = JsonStore.override(ctx, FILE)
            if (over != null && JsonStore.versionOf(over) >= JsonStore.versionOf(asset)) {
                runCatching { return parse(over, fromOverride = true) }
            }
            return parse(asset)
        }
    }
}

internal fun JSONArray?.strings(): List<String> =
    if (this == null) emptyList() else (0 until length()).map { optString(it) }.filter { it.isNotBlank() }

internal fun JSONArray?.doubles(): List<Double> =
    if (this == null) emptyList() else (0 until length()).map { optDouble(it) }.filter { !it.isNaN() }

object JsonStore {
    fun asset(ctx: Context, name: String): String =
        ctx.assets.open(name).use { it.readBytes().toString(Charsets.UTF_8) }

    fun override(ctx: Context, file: String): String? =
        runCatching { File(ctx.filesDir, file).takeIf { it.exists() }?.readText() }.getOrNull()

    fun versionOf(text: String): String =
        runCatching { JSONObject(text).optString("dbVersion", "") }.getOrDefault("")
}

// ---------------------------------------------------------------------------------------------
// Device / OS detection and compatibility checks
// ---------------------------------------------------------------------------------------------

data class DeviceInfo(
    val model: String,
    val androidRelease: String,
    val hyperosName: String?,
    val hyperos: Double?
) {
    val androidMajor: Int? get() = androidRelease.substringBefore('.').trim().toIntOrNull()

    val androidText: String get() = "Android $androidRelease"
    val hyperosText: String get() = hyperosName?.takeIf { it.isNotBlank() } ?: "نامشخص"

    companion object {
        val UNKNOWN = DeviceInfo(Build.MODEL ?: "?", Build.VERSION.RELEASE ?: "?", null, null)

        /** Reads a system property with the plain `getprop` binary (works for most ro.* values without ADB). */
        fun localProp(key: String): String = runCatching {
            val p = ProcessBuilder("getprop", key).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText().trim()
            p.waitFor()
            out
        }.getOrDefault("")

        fun parseHyperOs(osName: String?, incremental: String?): Double? {
            val num = Regex("(\\d+(?:\\.\\d+)?)")
            osName?.takeIf { it.isNotBlank() }?.let { n ->
                num.find(n)?.groupValues?.get(1)?.toDoubleOrNull()?.let { return it }
            }
            // fallback: build incremental like "OS3.0.5.0.WNQMIXM"
            Regex("OS(\\d+\\.\\d+)").find(incremental.orEmpty())?.groupValues?.get(1)?.toDoubleOrNull()?.let { return it }
            return null
        }

        fun fromProps(release: String, osName: String, uiName: String, incremental: String): DeviceInfo {
            val name = osName.ifBlank { uiName }.ifBlank { null }
            return DeviceInfo(
                model = Build.MODEL ?: "?",
                androidRelease = release.ifBlank { Build.VERSION.RELEASE ?: "?" },
                hyperosName = name,
                hyperos = parseHyperOs(osName, incremental)
            )
        }
    }
}

private fun OsSupport.warning(d: DeviceInfo): String? {
    val a = d.androidMajor
    if (a != null) {
        val lo = androidMin
        val hi = androidMax
        if ((lo != null && a < lo) || (hi != null && a > hi)) return "این مشخصات برای Android $a تأیید نشده است."
    }
    val h = d.hyperos
    if (h != null && hyperos.isNotEmpty() && hyperos.none { kotlin.math.abs(it - h) < 0.05 }) {
        return "این مشخصات برای HyperOS $h تأیید نشده است؛ نام بسته یا رفتارش ممکن است فرق کند."
    }
    return null
}

fun PkgInfo.osWarning(d: DeviceInfo): String? = os.warning(d)
