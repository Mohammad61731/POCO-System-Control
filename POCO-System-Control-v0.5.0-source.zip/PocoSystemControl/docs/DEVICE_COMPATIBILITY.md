# Device compatibility
Target: POCO X6 Pro, HyperOS global. minSdk 30 (Wireless debugging). Verify behavior on the device before relying on it.

## Multi-version design (v0.5.0)
Target: POCO X6 Pro on Android 16 / HyperOS 3; designed for Android 17, HyperOS 3.1 and HyperOS 4.
Each database record has `osSupport {androidMin, androidMax, hyperosVersions}` and optional `altPackages` (renamed packages). When Android 17 / HyperOS 3.1 / 4 appear, update the JSON only. All records are `verified: false` until compared with a real full scan of the phone.
