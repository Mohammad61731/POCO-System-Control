# Security rules
1. No root; no hidden actions. Every operation shows its exact command and needs confirmation.
2. Only typed operations (enum Op); package names must match a strict regex AND exist in the scanned inventory.
3. Protected packages (SystemUI, phone, settings, thermal, power, security, package installer, permission controller, GMS, launcher, vendor) are blocked for every operation.
4. Unknown system packages default to Caution.
5. Result is verified after state-changing operations and recorded in history.
6. Undo re-checks the current package state first.
7. Uninstall-for-user is distinct from disable and update removal.
8. Gaming mode must not alter thermal limits or CPU/GPU frequencies.
9. ADB key is stored in app-private storage; backup is disabled.
10. The package database can only add caution. `Safety.isProtected()` always wins; a database record with risk `dangerous` is treated as locked (PROTECTED).
11. Appearance tools: only `setprop` on the `persist.sys.` namespace, with strict regex on name and value; tools with any invalid command are dropped. The previous value is saved before a change and restored on Reset; the result is verified with `getprop` and a failed apply is rolled back.
12. Removing is never the default: Disable comes first in the detail screen and the confirm dialog advises testing for a few days before uninstalling.
