# Architecture
Single module, Kotlin + Compose (RTL). Files: Model.kt (apps, ops, safety policy), Adb.kt (libadb-android client + executor with verification),
MainViewModel.kt (state, pairing discovery, history), MainActivity.kt (3 tabs: connect / apps / history).

## v0.5.0 additions
- `assets/packages_db.json` + `PackageDb.kt`: per-package record (description, category, risk, battery impact, suggested action, side effects, OS support, devices, icon, alt package names). Importable from the app (Diagnosis tab); the highest `dbVersion` wins between the bundled and the imported file.
- `DeviceInfo` (in PackageDb.kt): Android release + HyperOS version, read through ADB (fallback: plain `getprop`). Used only to show compatibility notes; it never hides or blocks anything.
- `assets/appearance_tools.json` + `Appearance.kt`: appearance tools = lists of `setprop` commands; `ToolStore` keeps previous values for Reset; `AppearanceRunner` verifies with `getprop`.
- `MainActivity.kt`: 5 tabs (connect / apps / appearance / diagnosis / history), detail dialog, risk badges.
