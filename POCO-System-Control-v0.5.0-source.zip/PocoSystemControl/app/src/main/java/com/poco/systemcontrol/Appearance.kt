package com.poco.systemcontrol

import android.content.Context
import org.json.JSONObject
import java.io.File

// ---------------------------------------------------------------------------------------------
// HyperOS appearance tools (assets/appearance_tools.json).
// Each tool is a list of `setprop` commands. Nothing is free-text: property names and values are
// validated, the previous values are saved before any change, and the result is checked with getprop.
// ---------------------------------------------------------------------------------------------

data class PropCmd(val prop: String, val value: String)

data class AppearanceTool(
    val id: String,
    val nameFa: String,
    val nameEn: String,
    val descriptionFa: String,
    val commands: List<PropCmd>,
    val needs: String,            // none | restart
    val warningFa: String,
    val powerWarning: Boolean,
    val os: OsSupport
) {
    val runnable: Boolean get() = commands.isNotEmpty()
    val needsText: String?
        get() = if (needs == "restart") "ممکن است برای اعمال کامل، ری‌استارت SystemUI یا ریبوت لازم باشد." else null
}

data class ToolLink(val title: String, val url: String)

class ToolDb(val version: String, val tools: List<AppearanceTool>, val links: List<ToolLink>) {
    companion object {
        const val ASSET = "appearance_tools.json"
        const val FILE = "appearance_tools.json"
        val EMPTY = ToolDb("-", emptyList(), emptyList())

        // Only these property namespaces may ever be written; ro.* and everything else is refused.
        private const val ALLOWED_PREFIX = "persist.sys."
        private val propRegex = Regex("^[A-Za-z0-9._]{1,80}$")
        private val valueRegex = Regex("^[A-Za-z0-9._-]{0,40}$")

        fun isValid(c: PropCmd) = c.prop.startsWith(ALLOWED_PREFIX) && propRegex.matches(c.prop) && valueRegex.matches(c.value)

        fun parse(text: String): ToolDb {
            val root = JSONObject(text)
            require(root.optString("kind") == "tools") { "kind" }
            val arr = root.getJSONArray("tools")
            val tools = ArrayList<AppearanceTool>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id")
                if (!Regex("^[a-z0-9_]{1,40}$").matches(id)) continue
                val cmds = ArrayList<PropCmd>()
                val ca = o.optJSONArray("commands")
                var bad = false
                if (ca != null) for (j in 0 until ca.length()) {
                    val c = ca.optJSONObject(j) ?: continue
                    val cmd = PropCmd(c.optString("prop"), c.optString("value"))
                    if (isValid(cmd)) cmds += cmd else bad = true
                }
                if (bad) continue // a tool with any invalid command is dropped as a whole
                val osObj = o.optJSONObject("osSupport")
                tools += AppearanceTool(
                    id = id,
                    nameFa = o.optString("nameFa").ifBlank { id },
                    nameEn = o.optString("nameEn"),
                    descriptionFa = o.optString("descriptionFa"),
                    commands = cmds,
                    needs = o.optString("needs", "none"),
                    warningFa = o.optString("warningFa"),
                    powerWarning = o.optBoolean("powerWarning", false),
                    os = OsSupport(
                        osObj?.takeIf { it.has("androidMin") }?.optInt("androidMin"),
                        osObj?.takeIf { it.has("androidMax") }?.optInt("androidMax"),
                        osObj?.optJSONArray("hyperosVersions").doubles()
                    )
                )
            }
            require(tools.isNotEmpty()) { "empty" }
            val links = ArrayList<ToolLink>()
            root.optJSONArray("links")?.let { la ->
                for (i in 0 until la.length()) {
                    val l = la.optJSONObject(i) ?: continue
                    val url = l.optString("url")
                    if (url.startsWith("https://")) links += ToolLink(l.optString("title", url), url)
                }
            }
            return ToolDb(root.optString("dbVersion", "0"), tools, links)
        }

        fun load(ctx: Context): ToolDb {
            val asset = JsonStore.asset(ctx, ASSET)
            val over = JsonStore.override(ctx, FILE)
            if (over != null && JsonStore.versionOf(over) >= JsonStore.versionOf(asset)) {
                runCatching { return parse(over) }
            }
            return parse(asset)
        }
    }
}

fun AppearanceTool.osWarning(d: DeviceInfo): String? = os.warningText(d)

private fun OsSupport.warningText(d: DeviceInfo): String? {
    val h = d.hyperos
    if (h != null && hyperos.isNotEmpty() && hyperos.none { kotlin.math.abs(it - h) < 0.05 }) {
        return "برای HyperOS $h تأیید نشده؛ بعد از اجرا نتیجه بررسی می‌شود."
    }
    return null
}

/** Remembers the values that were in place before a tool changed them, so they can be restored. */
class ToolStore(ctx: Context) {
    private val file = File(ctx.filesDir, "tool_prior.json")

    private fun read(): JSONObject = runCatching { JSONObject(file.readText()) }.getOrDefault(JSONObject())

    fun get(id: String): Map<String, String>? {
        val o = read().optJSONObject(id) ?: return null
        return o.keys().asSequence().associateWith { o.optString(it) }
    }

    fun save(id: String, values: Map<String, String>) {
        val root = read()
        root.put(id, JSONObject(values))
        runCatching { file.writeText(root.toString()) }
    }

    fun clear(id: String) {
        val root = read()
        root.remove(id)
        runCatching { file.writeText(root.toString()) }
    }
}

object AppearanceRunner {
    private suspend fun readProps(adb: AppAdbManager, props: List<String>): Map<String, String> =
        props.associateWith { adb.exec("getprop $it").trim() }

    /** true = every property already has the tool's target value. */
    suspend fun isApplied(adb: AppAdbManager, tool: AppearanceTool): Boolean {
        if (!tool.runnable) return false
        val cur = readProps(adb, tool.commands.map { it.prop })
        return tool.commands.all { cur[it.prop] == it.value }
    }

    private suspend fun set(adb: AppAdbManager, prop: String, value: String) {
        adb.exec("setprop $prop \"$value\"")
    }

    suspend fun apply(adb: AppAdbManager, tool: AppearanceTool, store: ToolStore): OpResult {
        if (!tool.runnable || !tool.commands.all(ToolDb::isValid)) return OpResult(false, "دستور معتبری برای این ابزار نیست")
        val before = readProps(adb, tool.commands.map { it.prop })
        val alreadyApplied = tool.commands.all { before[it.prop] == it.value }
        if (!alreadyApplied && store.get(tool.id) == null) store.save(tool.id, before)

        runCatching { tool.commands.forEach { set(adb, it.prop, it.value) } }
            .onFailure { return OpResult(false, it.localizedMessage ?: "خطا در اجرای دستور") }

        val after = readProps(adb, tool.commands.map { it.prop })
        val ok = tool.commands.all { after[it.prop] == it.value }
        if (ok) return OpResult(true, tool.nameFa)

        // Not applied (no permission, or this build ignores the property): put back what was there.
        runCatching {
            tool.commands.forEach { c -> if (after[c.prop] != before[c.prop]) set(adb, c.prop, before[c.prop].orEmpty()) }
        }
        if (!alreadyApplied) store.clear(tool.id)
        val got = tool.commands.joinToString("، ") { "${it.prop}=${after[it.prop].orEmpty().ifBlank { "(خالی)" }}" }
        return OpResult(false, "اعمال نشد (روی این نسخه یا بدون دسترسی بیشتر کار نمی‌کند). مقدار بعد از اجرا: $got")
    }

    suspend fun revert(adb: AppAdbManager, tool: AppearanceTool, store: ToolStore): OpResult {
        if (!tool.runnable || !tool.commands.all(ToolDb::isValid)) return OpResult(false, "دستور معتبری برای این ابزار نیست")
        val prior = store.get(tool.id)
        // No saved value (applied outside this app): fall back to clearing the property.
        val target = tool.commands.associate { it.prop to (prior?.get(it.prop).orEmpty()) }
        runCatching { target.forEach { (p, v) -> set(adb, p, v) } }
            .onFailure { return OpResult(false, it.localizedMessage ?: "خطا در اجرای دستور") }
        val after = readProps(adb, target.keys.toList())
        val ok = target.all { (p, v) -> after[p] == v }
        if (ok) store.clear(tool.id)
        return OpResult(ok, if (ok) tool.nameFa else "بازگردانی تأیید نشد؛ مقدار فعلی را بررسی کن")
    }
}
