package com.poco.systemcontrol

import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date

/** Built-in ADB client that talks to this phone's own adbd through Wireless debugging. */
class AppAdbManager private constructor(ctx: Context) : AbsAdbConnectionManager() {

    private val keys: Pair<PrivateKey, Certificate> = loadOrCreate(ctx)

    init {
        setApi(Build.VERSION.SDK_INT)
        setHostAddress("127.0.0.1")
    }

    override fun getPrivateKey(): PrivateKey = keys.first
    override fun getCertificate(): Certificate = keys.second
    override fun getDeviceName(): String = "POCOSystemControl"

    suspend fun exec(command: String): String = withContext(Dispatchers.IO) {
        val stream = openStream("shell:$command")
        try {
            stream.openInputStream().bufferedReader().readText()
        } finally {
            runCatching { stream.close() }
        }
    }

    companion object {
        @Volatile private var instance: AppAdbManager? = null

        fun get(ctx: Context): AppAdbManager = instance ?: synchronized(this) {
            instance ?: AppAdbManager(ctx.applicationContext).also { instance = it }
        }

        private fun loadOrCreate(ctx: Context): Pair<PrivateKey, Certificate> {
            val keyFile = File(ctx.filesDir, "adb_key.pk8")
            val certFile = File(ctx.filesDir, "adb_cert.der")
            runCatching {
                if (keyFile.exists() && certFile.exists()) {
                    val k = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyFile.readBytes()))
                    val c = certFile.inputStream().use { CertificateFactory.getInstance("X.509").generateCertificate(it) }
                    return k to c
                }
            }
            val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
            val name = X500Name("CN=POCOSystemControl")
            val now = System.currentTimeMillis()
            val builder = JcaX509v3CertificateBuilder(
                name, BigInteger.valueOf(now), Date(now - 86_400_000L),
                Date(now + 10L * 365 * 86_400_000L), name, kp.public
            )
            val signer = JcaContentSignerBuilder("SHA256withRSA").build(kp.private)
            val cert = JcaX509CertificateConverter().getCertificate(builder.build(signer))
            keyFile.writeBytes(kp.private.encoded)
            certFile.writeBytes(cert.encoded)
            return kp.private to cert
        }
    }
}

data class OpResult(val ok: Boolean, val text: String)

object Executor {
    private suspend fun pkgs(adb: AppAdbManager, args: String): Set<String> =
        adb.exec("pm list packages $args").lineSequence()
            .map { it.trim() }
            .filter { it.startsWith("package:") }
            .map { it.removePrefix("package:") }
            .toSet()

    suspend fun run(adb: AppAdbManager, op: Op, pkg: String, inventory: List<AppItem>): OpResult {
        if (!Safety.isValid(pkg)) return OpResult(false, "نام بسته نامعتبر است")
        val item = inventory.firstOrNull { it.pkg == pkg }
            ?: return OpResult(false, "این بسته در فهرست اسکن‌شده نیست")
        if (item.risk == Risk.PROTECTED) return OpResult(false, "برنامهٔ محافظت‌شده است")

        val out = runCatching { adb.exec(commandFor(op, pkg)) }
            .getOrElse { return OpResult(false, it.localizedMessage ?: "خطا در اجرای دستور") }
            .trim()

        val verified = runCatching {
            when (op) {
                Op.DISABLE -> pkg in pkgs(adb, "-d --user 0")
                Op.ENABLE -> pkg in pkgs(adb, "-e --user 0")
                Op.UNINSTALL_USER, Op.UNINSTALL_FULL -> pkg !in pkgs(adb, "--user 0")
                Op.RESTORE -> pkg in pkgs(adb, "--user 0")
                else -> !Regex("Exception|Failure|Error|Unknown", RegexOption.IGNORE_CASE).containsMatchIn(out)
            }
        }.getOrDefault(false)

        return OpResult(verified, if (verified) item.label else out.ifBlank { "اجرا نشد یا وضعیت تغییر نکرد" })
    }
}
