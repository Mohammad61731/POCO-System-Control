package com.poco.systemcontrol

import android.app.Application
import org.conscrypt.Conscrypt
import java.security.Security

class PocoApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // TLS 1.3 provider required by the wireless-debugging ADB protocol.
        Security.insertProviderAt(Conscrypt.newProvider(), 1)
    }
}
