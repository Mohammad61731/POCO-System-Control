package com.poco.systemcontrol

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object PairingHelper {
    const val CHANNEL = "pairing"
    const val ACTION = "com.poco.systemcontrol.PAIR"
    const val KEY_CODE = "code"
    private const val NOTIF_ID = 4242

    /** Last pairing port found through mDNS; updated while discovery is running. */
    @Volatile var port: Int? = null

    fun showNotification(ctx: Context, text: String, withInput: Boolean) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "جفت‌سازی ADB", NotificationManager.IMPORTANCE_HIGH))
        val b = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("POCO System Control")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setAutoCancel(!withInput)
        if (withInput) {
            val intent = Intent(ACTION).setPackage(ctx.packageName)
            val pi = PendingIntent.getBroadcast(
                ctx, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            val ri = RemoteInput.Builder(KEY_CODE).setLabel("کد ۶ رقمی").build()
            b.addAction(
                NotificationCompat.Action.Builder(android.R.drawable.ic_menu_send, "ارسال کد", pi)
                    .addRemoteInput(ri).build()
            )
        }
        runCatching { nm.notify(NOTIF_ID, b.build()) }
    }
}

class PairReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val code = RemoteInput.getResultsFromIntent(intent)
            ?.getCharSequence(PairingHelper.KEY_CODE)?.toString()?.trim().orEmpty()
        val port = PairingHelper.port
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            val msg = try {
                when {
                    port == null -> "پورت جفت‌سازی پیدا نشد؛ صفحهٔ «جفت‌سازی با کد» باید باز باشد"
                    code.length != 6 -> "کد باید ۶ رقم باشد"
                    else -> {
                        val adb = AppAdbManager.get(context)
                        val ok = adb.pair("127.0.0.1", port, code)
                        if (ok) {
                            runCatching { adb.connectTls(context, 8_000L) }
                            "جفت‌سازی موفق بود؛ به برنامه برگرد"
                        } else "جفت‌سازی ناموفق بود؛ دوباره امتحان کن"
                    }
                }
            } catch (e: Exception) {
                "خطا: ${e.localizedMessage}"
            }
            PairingHelper.showNotification(context, msg, withInput = false)
            pending.finish()
        }
    }
}
